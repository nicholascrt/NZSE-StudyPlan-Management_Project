<?php include '../php_includes/check_session_tutor_and_html.php'; ?>
<head>
	<?php $title="NZSE"; ?>
	<?php include '../php_includes/head_elements.php' ?>
</head>
	
	<div class="page-break">
	<div id="nzseLogo">
		<img src="../pic/nzseLogo.png" alt="nzseLogo">
	</div><!--nzseLogo-->
	<nav><br />
	<h2>Study Agreement</h2>
	</nav>
	
	<p id="date">Date:</p>

	<?php
	$studentid = $_SESSION['studentid'];
	
		include '../php_script/connectDB.php';
			$result = "SELECT resit.studentid,userid.username, resit.cohort, resit.date
			FROM resit INNER JOIN userid 
			ON resit.studentid=userid.id 
			WHERE resit.studentid='".$studentid."'";	
		if ($runquery = $conn->query($result))
	{
		while($row = $runquery->fetch_assoc())
		{ $username=$row['username'];$studentID=$row['studentid'];$cohort=$row['cohort'];
		$date=$row['date'];}
	}
		mysqli_close($conn);
			?>
			
			<?php
		$studentid = $_SESSION['studentid'];
	
		include '../php_script/connectDB.php';
		
			$queryresit = "SELECT date
			FROM resit
			WHERE studentid='".$studentid."'
			order by date";
		$runresit = mysqli_query($conn, $queryresit);
		$rowresit = mysqli_fetch_row($runresit);
		$enddate1=$rowresit[0];
		
		$queryreenrollment = "SELECT startdate
			FROM reenrollment
			WHERE studentid='".$studentid."'
			order by startdate";
		$runreenrollment = mysqli_query($conn, $queryreenrollment);
		$rowreenrollment = mysqli_fetch_row($runreenrollment);
		$enddate2=$rowreenrollment[0];
		
		if ($enddate1 > $enddate2){
			$startdate=$enddate2;
		}
		else{
			$startdate=$enddate1;
		}
	mysqli_close($conn);
			?>
			
			<?php
		$studentid = $_SESSION['studentid'];
	
		include '../php_script/connectDB.php';
		
			$queryresit = "SELECT date
			FROM resit
			WHERE studentid='".$studentid."'
			order by date desc";
		$runresit = mysqli_query($conn, $queryresit);
		$rowresit = mysqli_fetch_row($runresit);
		$enddate1=$rowresit[0];
		
		$queryreenrollment = "SELECT enddate
			FROM reenrollment
			WHERE studentid='".$studentid."'
			order by enddate desc";
		$runreenrollment = mysqli_query($conn, $queryreenrollment);
		$rowreenrollment = mysqli_fetch_row($runreenrollment);
		$enddate2=$rowreenrollment[0];
		
		if ($enddate1 > $enddate2){
			$enddate=$enddate1;
		}
		else{
			$enddate=$enddate2;
		}
	mysqli_close($conn);
			?>
	<table class="front">
		<tr>
			<th>Student Name</th>
			<td colspan="3"><?php echo $username; ?></td>
		</tr>
		<tr>
			<th>Student ID</th>
			<td><?php echo $studentID; ?></td>
			<th>Cohort</th>
			<td><?php echo $cohort; ?></td>
		</tr>
		<tr>
			<th>Reasons for Extension</th>
			<td colspan="3">To complete pending assessment resits.</td>
		</tr>
	</table>
	<br>
	<h3 id="under">Specific Terms and Conditions</h3>
	<h5>The period of this agreement is from 	<?php echo $startdate; ?> to <?php echo $enddate; ?></h5>
		<ul class="small">
		<li>I understand that I must attend each of the appointments and meet all deadlines and attendance requirements that have been scheduled in the action plan.</li>
		<li>I understand that I must inform NZSE of any issue that may affect my ability to successfully meet my requirements under this agreement.</li>
		<li>I understand that if I miss any of the tasks in the action plan then they will not be rescheduled. There will be no further extension or reassessments granted. This is my final chance.</li>
		</ul>
		<br>
	<p>I agree the above terms and conditions as stated in this agreement.</p>
	<br />
	<p class="wider">Student &ensp;&ensp;&emsp;&emsp;&emsp;&emsp;<?php echo $username; ?>&ensp;&ensp;&ensp;&ensp;&ensp;&emsp;___________________ &ensp;&ensp;&emsp;___________________</p>
	<p class="wider">Program Leader &ensp;&thinsp;&ensp;____________________ &emsp;&thinsp;&ensp;&ensp;___________________ &emsp;&ensp;&ensp;___________________</p>
	<p>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Name &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; Signature &emsp;&emsp;&emsp;&thinsp;&emsp;&emsp;&emsp;&emsp;&emsp;Date</p>
	
	</div>

<script>
	function myFunction() {
    window.print();}
	var now = new Date();
	document.getElementById("date").innerText="Date : " + now.toLocaleDateString();
</script>
	
<body>
<?php include '../php_includes/header_elements.php'; ?>
<?php include '../php_includes/print_icon.php'; ?>

	<div class="tables">
	
	<?php
	$studentid = $_SESSION['studentid'];
		include '../php_script/connectDB.php';
		
		$result = "SELECT assessment.title, assessment.number,courses.moduleid,assessment.type,courses.modulename, 
		resit.comment,resit.comment2,resit.comment3, resit.studyhours, resit.date, resit.time 
		FROM resit INNER JOIN assessment ON assessment.assessmentid=resit.assessmentid 
		INNER JOIN courses 
		ON assessment.moduleid=courses.moduleid 
		WHERE resit.studentid='".$studentid."'";	
		if ($runquery = $conn->query($result))
		{
			$count=0;
			while($row = $runquery->fetch_assoc())
			{
			$count++;
			if($count > 4)
			{echo "<div class='gap'></div>";$count=0;}
			echo " <table class='border'>";
			echo "<tr><th colspan='2' width='40%'>".$row['moduleID']."".$row['modulename']."<th colspan='2' width='20%'>Type: Resit
			<th width='30%'>check:  </th></tr>";
			echo "<tr><td colspan='5' width='100%'>".$row['number']."-" . $row['title'] ." (". $row['type'].")</td></tr>";
			echo "<tr><td colspan='2'>Due Date: " . $row['date'] . "</td><td>Time: ".$row['time']."</td>
			<td colspan='2'>Totle hours of study: " . $row['studyhours'] . "</td></tr>";
			echo "<tr>";
			if($row['comment']!="") 
			{
			echo "<td class='comment' colspan='5'><ul><li>" . $row['comment'] . "</li>";
			if($row['comment2']!="")
			{
			echo "<li>".$row['comment2']."</li>";
			if($row['comment3']!="")
			{
			echo "<li>".$row['comment3']."</li></ul></td>";
			}
			else{echo "</ul></td>";}
			}
			else
			{
				echo "</ul></td>";
			}
			}
			elseif ($row['comment2']!="")
			{
				echo "<td class='comment' colspan='5'><ul><li>" . $row['comment2'] . "</li>";
				if($row['comment3']!="")
				{
					echo "<li>".$row['comment3']."</li></ul></td>";
				}
			}
			elseif ($row['comment3']!="")
			{
				echo "<td class='comment' colspan='5'><ul><li>" . $row['comment3'] . "</li></ul></td>";
			}
			else
			{echo "<td class='comment' colspan='5'></td>";}
			echo "</tr></table> <br>";
		}
		$_SESSION['table_count']=$count;
		}
		echo"<br>";
		mysqli_close($conn);
		include './tutor_view_student_reenroll.php';
	?>
	
	<a id="back" href = "../tutor_home/tutor_search_schdule_page.php">Back</a>
	</div>
	<br>	<br>	<br>
	<?php include '../php_includes/footer.php'?>
</body>

</html>