<?php session_start(); ?>
<?php
include './connectDB.php';
//Create the query
$query = "SELECT * FROM userid";

//Run the query
$runquery = mysqli_query($conn, $query);

//Compare the results with the login information
$username = trim($_POST['uname']);
$password = md5($_POST['passwd']);

if(empty($username)||empty($password))
{	
	$_SESSION["error"] = "Please fill in all fields";
	header('location: ../index.php'); 
	exit();
}

while($row = mysqli_fetch_assoc($runquery)) 
{
 if($username == $row['id'] && $password == $row['password'])
 {
	$_SESSION["username"] = $row['username'];
	$_SESSION["userid"] = $row['id'];
	$_SESSION["usertype"] = $row['usertype'];
	if($row['usertype']== 1)
	{	
		header('location: ../tutor_home/tutor_page.php'); 
	}
	elseif($row['usertype']== 3)
	{
		header('location: ../admin_home/admin_page.php'); 
	}
	else
	{
		header('location: ../student_home/student_page.php'); 
	}
	mysqli_close($conn); 
	exit();
 }
}

// Step 5: Close the connection to the server
mysqli_close($conn); 
$_SESSION["error"] = "Wrong username or password, please try again.";
header('location: ../index.php');
?>