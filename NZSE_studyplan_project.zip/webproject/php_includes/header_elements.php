<div id = "header">
	<?php echo strtoupper($title); ?>
	</div>	
<div id='header_elements'>
	
		<?php include '../php_includes/nzseLogo.php'; ?>
	
	<div id="contact">
		<img src="../pic/contact.png" alt="contact">
	</div><!--contact logo-->
	<?php include '../php_includes/menu_check.php' ?>
<?php include '../php_includes/logoutbutton.php' ?>
<?php include '../php_includes/navibar.php' ?>
</div>