<div id="nzseLogo">
<?php
	if(isset($_SESSION['usertype']))
	{
		if ($_SESSION['usertype']==1){
			print "	<a href='../tutor_home/tutor_page.php'>
		<img src='../pic/nzseLogo.png' alt='home'></a>";
		}
		elseif ($_SESSION['usertype']==3){
			print "	<a href='../admin_home/admin_page.php'>
		<img src='../pic/nzseLogo.png' alt='home'></a>";
		}
		else {
			print "	<a href='../student_home/student_page.php'>
		<img src='../pic/nzseLogo.png' alt='home'></a>";
		}
	}

?>
</div><!--nzse logo-->