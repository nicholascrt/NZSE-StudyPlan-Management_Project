<div id='footer'>
		<p>Copyright © NZSE 2015</p>  
</div>