<div id="menu">
<?php
	if(isset($_SESSION['usertype']))
	{
		if ($_SESSION['usertype']==1){
			print "<a href='../tutor_home/tutor_page.php'>Tutor page</a>";
		}
		elseif ($_SESSION['usertype']==3){
			print "<a href='../admin_home/admin_page.php'>Admin page</a>";
		}
		else {
			print "<a href='../student_home/student_page.php'>Student page</a>";
		}
	}

?>
</div><!--menu-->