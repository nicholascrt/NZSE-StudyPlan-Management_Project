	<div id="logout_button">
<?php 
if(isset($_SESSION['usertype']))
		{
			print "<form action='../php_script/logout.php'>";
			print "<input type='submit' value='logout'>";
			print "</form>";
		}
?>
</div><!--logoutbutton-->