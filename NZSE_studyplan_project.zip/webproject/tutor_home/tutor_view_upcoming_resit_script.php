<?php include '../php_includes/check_session_tutor_and_html.php'; ?>
<head>
	<?php $title="view upcoming"; ?>
	<?php include '../php_includes/head_elements.php' ?>
<script>
	function myFunction() {
    window.print();}
</script>
</head>
<body>
<?php include '../php_includes/header_elements.php' ?>

<?php include '../php_includes/print_icon.php'; ?>
	<div class="tables">
	<?php
	
		include '../php_script/connectDB.php';
		
		$query = "SELECT r.*, a.title,a.assessmentid, u.username
		FROM resit r, assessment a, userid u
		WHERE r.assessmentid=a.assessmentid
		and r.studentid=u.id
		and r.date >= '".$_SESSION["fromdate"]."'
		and r.date <= '".$_SESSION["todate"]."'
		order by r.date, a.assessmentid";
		
		$result = mysqli_query($conn, $query);

		
		echo "<table id='upcoming' class='border'>
		<tr>
		<th id='hidden'></th>		
		<th>Assesment Title</th>
		<th>Student ID</th>		
		<th>Student Name</th>
		<th>Cohort</th>
		<th>Assessment due date</th>		
		</tr>";
		$comp="";
		while($row = mysqli_fetch_assoc($result))
		{
			echo "<tr class='date_row'>";
			if($comp != $row['date'] || $comp=="")
			{
			$temp = date('l', strtotime($row['date']));
			echo "<td class='date'><h1>$temp<span class='arrow'></span></h1></td>";
			}
			else
			{
				echo "<td class='no_date'></td>";
			}
			
			echo "<td>".$row['assessmentid']."<br>".$row['title']."</td>";
			echo "<td>" . $row['studentid']."</td>";
			echo "<td>" . $row['username']."</td>";
			echo "<td>" . $row['cohort']."</td>";

		echo "<td>" . $row['date'] . "<br>".$row['time']."</td>";
		
		$comp=$row['date'];
		echo "</tr>";			
		}
		echo "</table>";
		echo"<br>";
		mysqli_close($conn);
		
		echo"<br>";
	?>
	</div>
	<a id="back" href = "../tutor_home/tutor_page.php">Back</a>
	<br><br><br><br><br>
	<?php include '../php_includes/footer.php'?>
</body>

</html>