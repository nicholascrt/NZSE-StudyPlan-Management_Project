<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">

<head>
	<title>NZSE webproject</title>
	<meta http-equiv="Content-type" content="text/html;charset=UTF-8"/>
	<link rel="stylesheet" href="./css/mystyle.css"/>
</head>

<body>
<div id='container'>
	
	<div id="header">
	<h1>Welcome to NZSE!</h1>
	</div><!--header-->
	<div id="logoutbutton">
		<?php 
			if(isset($_SESSION['checkAdmin']))
				{
					print "<form action='./php_script/logout.php'>";
					print "<input type='submit' value='logout'>";
					print "</form>";
				}		
		?>
	</div><!--logoutbutton-->
	
	<div id="menu">
	<a href='./index.php'>Homepage</a>
	<?php 
		if(isset($_SESSION['checkAdmin']))
	{
		if ($_SESSION['checkAdmin']==1){
			print "<a href='./tutor_home/tutor_page.php'>Tutor page</a>";
		}
		else{
			print "<a href='./student_home/student_page.php'>Student page</a>";
		}
	}
	?>
	</div><!--menu-->
	
	<div id="errorMessage">
	<h1>You dont't have permission to access this page, click <a href='./index.php'>here</a> to try again.</h1>
	</div><!--errorMessage-->
	
</div><!--container-->


		<?php include './php_includes/footer.php'?>
</body>

</html>