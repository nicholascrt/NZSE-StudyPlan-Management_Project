<?php session_start(); ?>
<?php 
	if(!isset($_SESSION['usertype'])|| $_SESSION['usertype']!=0){
		header('location:../error_page.php');
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
	<?php $title="request resit"; ?>
	<?php include '../php_includes/head_elements.php' ?>
	<script>
function showModule(str) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("txtHint1").innerHTML = xmlhttp.responseText;
            }
        }
        xmlhttp.open("GET","../php_script/getAssessmentForm_script.php?moduleId="+str,true);
        xmlhttp.send();
    }
</script>
</head>

<body>
		<?php include '../php_includes/header_elements.php' ?>
<div id="container">
<div id="error">
		<?php
				if(isset($_SESSION['error']))
				{	
					print $_SESSION['error'];
					if(isset($_SESSION['lead']))
					{
						print $_SESSION['lead'];
					}
					unset($_SESSION['error']);
					unset($_SESSION['lead']);
				}
		?>
</div>

<form id="form1" action="./student_requestresit_page.php" method="post">
				<fieldset>
				<legend>Contact form</legend>
				<p class="first">
					<label for="studentid">Student id:<?php echo $_SESSION['userid'];?></label>
					<input type="text" name="name" id="name" size="30" />
				</p>
				<p>
					<label for="cohort">Cohort:</label>
					<input type="text" name="cohort" /><br />
				</p>
				<?php include '../php_script/getModuleForm_script.php'?>
				<p>
					<label id="txtHint1">Assessment:</label><br />
				</p>

				<p>
					<label for="date">Date:</label>
					<input type="date" name="date" value="date" /><br />
				</p>

				<p>
					<label for="time">Time:</label>
					<input type="time" name="time" value="time" /><br />
				</p>

				
			</fieldset>
			<fieldset>																			
				<p>
					<label for="text">Comment:</label>
					<textarea name="comment" rows="3" cols="40"></textarea>
				</p>								
			</fieldset>					

			<p class="submit"><button type="submit" name="requestResit">Submit</button></p>		
						
		</form>	
</div>
<?php
if (isset($_POST['requestResit'])){
include '../php_script/connectDB.php';

$studentid = $_SESSION['userid'];
$cohort = trim($_POST['cohort']);
$moduleid = trim($_POST['moduleid']);
$assessmentid = trim($_POST['assessmentid']);
$date = trim($_POST['date']);
$time = trim($_POST['time']);
$comment = trim($_POST['comment']);

if (empty($studentid)||empty($cohort)||empty($moduleid)||empty($assessmentid)
	||empty($date)||empty($time))
{
	$_SESSION['error']="Please fill in all fields";
	header('location: ./student_requestresit_page.php'); 
	exit();
}

$query = "SELECT COUNT(*) as cnt FROM studentresitrequest WHERE studentID= '".$studentid."'";

$runquery = mysqli_query($conn, ($query));
if($runquery){
$_SESSION["studentid"] = $studentid;
$_SESSION["cohort"] =$cohort;
$_SESSION["moduleid"] =$moduleid;
$_SESSION["assessmentid"] =$assessmentid;
$_SESSION["date"] =$date;
$_SESSION["time"] =$time;
$_SESSION["comment"] =$comment;
$row = mysqli_fetch_array($runquery); 
$cnt = $row['cnt'];
}
if($cnt > 5)
{
	$_SESSION['error'] = "Cannot be having more than 4 resits at the same time.";
	header('location: ./student_requestresit_page.php'); 
	exit();
 } 
	header('location: ../php_script/student_requestresitconfirm_script.php');
  mysqli_close($conn);
}
 ?>
	<?php include '../php_includes/footer.php'?>
</body>
</html>	
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-783567-1";
urchinTracker();
</script>			