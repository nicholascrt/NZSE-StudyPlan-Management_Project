	<div id="print">
		<img src="../pic/printer.png" onclick="myFunction()"></img>
	</div><!--print-->