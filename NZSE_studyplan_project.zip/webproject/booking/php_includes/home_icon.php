<div id="home">
		<a href="http://nzse.ac.nz/">
		<img src="../pic/home.png" alt="home"></a>
	</div><!--home logo-->