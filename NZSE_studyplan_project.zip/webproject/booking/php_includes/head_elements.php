<link rel="stylesheet" href="../css/main_style.css" type="text/css" media="all">
	<meta http-equiv="Content-type" content="text/html;charset=UTF-8"/>	
	<title><?php echo "$title"; ?></title>