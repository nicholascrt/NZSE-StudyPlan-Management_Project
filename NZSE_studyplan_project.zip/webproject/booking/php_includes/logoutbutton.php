	<div id="logout_button">
<?php 
if(isset($_SESSION['usertype']))
		{
			
			print "<form action='../php_script/logout.php'>";
			print "<span>".$_SESSION["username"]."&emsp; </span> <input type='submit' value='logout'>";
			print "</form>";
		}
?>
</div><!--logoutbutton-->