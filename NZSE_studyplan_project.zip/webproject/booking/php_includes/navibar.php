<?php
		if ($_SESSION['usertype']==1 || $_SESSION['usertype']==3){
			print "<div id='nav'>
				<ul>
            <li><a href='../tutor_home/tutor_resitform_page.php'>CREATE RESIT</a></li>
			<li><a href='../tutor_home/tutor_reenroll_page.php'>CREATE RE-ENROLLMENT</a></li>
			<li><a href='../tutor_home/tutor_view_upcoming_page.php'>VIEW UP-COMING RESITS</a></li>
			<li><a href='../tutor_home/tutor_registerstudent_page.php'>REGISTER STUDENT</a></li>
			<li><a href='../tutor_home/tutor_search_schdule_page.php'>GENERATE STUDY PLAN</a></li>
            <li><a href='#'>ADDITIONAL FEATURES <img src='../pic/arrow.png' height='9px' alt='arrow'/></a>
               
                    <ul>
                        <li><a href='../tutor_home/tutor_create_module_page.php'>Add/Edit Module</a></li>
                        <li><a href='../tutor_home/tutor_create_assessment_page.php'>Add/Edit Assessment</a></li>
						<li><a href='../tutor_home/tutor_search_schdule_for_delete_page.php'>Delete Resit/Re-enroll </a></li>
						<li><a href='../tutor_home/tutor_changepw_page.php'> Change password </a></li>
						<li><a href='../tutor_home/tutor_changeprofile_page.php'> Change profile </a></li>                
                    </ul>
         
            </li>
        </ul>
    </div>";
	}
?>