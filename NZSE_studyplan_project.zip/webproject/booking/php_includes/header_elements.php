<header>
<?php echo strtoupper($title)."";
?>
</header>	
<div id='header_elements'>
	
<?php include '../php_includes/nzseLogo.php'; ?>
<?php include '../php_includes/menu_check.php'; ?>
<?php include '../php_includes/logoutbutton.php'; ?>
</div>