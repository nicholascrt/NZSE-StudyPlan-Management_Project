<?php include '../php_includes/check_session_tutor_and_html.php'; ?>
<head>
	<?php $title="add assessment"; ?>
	<?php include '../php_includes/head_elements.php'; ?>
	<script src="../js/jquery-1.9.1.js"></script>
	<script src="../js/alertify.min.js"></script>
	<link rel="stylesheet" href="../css/css_alertboxes/alertify.core.css" />
	<link rel="stylesheet" href="../css/css_alertboxes/alertify.default.css" />
</head>

<body>
	
<?php include "../php_includes/header_elements.php"; ?>
<div id='error'>
		<?php
				if(isset($_SESSION['error']))
				{	
					print $_SESSION['error'];	
					unset($_SESSION['error']);
				}
				
		?>
</div><!--error--><br />

<div id="container">
<form id="form1" name="assessments" action="./tutor_create_assessment_script.php" method="get">
<fieldset>
<br>
<?php include '../php_script/getModuleForm_script.php';?>
<br />
	<p class="first">
	<label for="title">Assessment Title:</label>
	<input type="text" name="title"/><br />
	</p>
	<p>
	<label for="type">Assessment Type:</label>
	<input type="text" name="type"/><br />	
	</p>
	<p>
	<label for="number">Assessment Number:</label>
	<input type="text" name="number"/><br />
	</p>
</fieldset>
<p class="submit">
	<button type="submit" name="submit">submit</button><br />
	</p>
</form>
</div><!--container-->
<script>

		$("#form1").on('submit', function () 
		{	
			var flag;
			var d = 5000;
			var moduleid = document.forms["assessments"]["moduleid"].value;
			if (moduleid == null || moduleid == "Select a module") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("moduleid must be filled out");
				flag=false;
			}
			var title = document.forms["assessments"]["title"].value;
			if (title == null || title == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("title must be filled out");
				flag=false;
			}
			
			var number = document.forms["assessments"]["number"].value;
			if (number == null || number == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("number must be filled out.");
				flag=false;
			}
			var type = document.forms["assessments"]["type"].value;
			if (type == null || type == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("type must be filled out.");
				flag=false;
			}
			
			return flag;
		});
	</script>
	
	
	
	

	<a id="back" href="./tutor_create_assessment_page.php">&emsp;Go back to view assessments</a>
<br><br><br><br><br><br><br><br><br>
<?php include '../php_includes/footer.php'; ?>
</body>
</html>		