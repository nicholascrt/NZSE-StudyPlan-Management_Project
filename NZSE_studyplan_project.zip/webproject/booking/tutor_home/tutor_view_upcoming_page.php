<?php include '../php_includes/check_session_tutor_and_html.php'; ?>
<head>
	<?php $title="select date"; ?>
	<?php include '../php_includes/head_elements.php' ?>
	<script src="../js/jquery-1.9.1.js"></script>
<script src="../js/alertify.min.js"></script>
<link rel="stylesheet" href="../css/css_alertboxes/alertify.core.css" />
<link rel="stylesheet" href="../css/css_alertboxes/alertify.default.css" />
</head>
<?php
if (isset($_POST['submitrequest'])){
include '../php_script/connectDB.php';
$fromdate = trim($_POST['fromdate']);
$todate = trim($_POST['todate']);
$sql = "SELECT date FROM resit WHERE resit.date >= '".$fromdate."'
		and resit.date <=  '".$todate."'";
$result = $conn->query($sql);
if (empty($fromdate)||empty($todate))
{
	$_SESSION['error']="Please select dates you want to view";
	header('location: ./tutor_view_upcoming_page.php'); 
	exit();
}


if ($result->num_rows > 0) {
	$_SESSION["fromdate"] = $fromdate;
	$_SESSION["todate"] = $todate;
		//header('location: ../confirmResitForm.php');
		

header('location: ./tutor_view_upcoming_resit_script.php');
}

else
{
	$_SESSION['error'] = "There is no resit.";
	
	header('location: ./tutor_view_upcoming_page.php'); 
	exit();
} 
$conn->close();
}

?>
<body>
<?php include '../php_includes/header_elements.php' ?>		
		
		<div id='error'>
		<?php
				if(isset($_SESSION['error']))
				{	
					print $_SESSION['error'];
					unset($_SESSION['error']);
				}
		?>
		</div>		
<div id="container">
			
		<form id="form1" action="./tutor_view_upcoming_page.php" method="post">	

			<fieldset><legend>Contact form</legend>
				<p class="first">
					<label for="fromdate">From Date:</label>
	<input type="date" name="fromdate" /><br />	
				</p>
				<p>
					<label for="date">To Date:</label>
	<input type="date" name="todate" /><br /><br />
				</p>
						
			</fieldset>					

			<p class="submit"><button type="submit" name="submitrequest">submit</button></p>		
						
		</form>	
</div>
<script>
	$("#form1").on('submit', function () 
		{	
			var flag;
			var d = 5000;
			var fromdate = document.forms["form1"]["fromdate"].value;
			if (fromdate == null || fromdate == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("choose startdate");
				flag=false;
			}
			var todate = document.forms["form1"]["todate"].value;
			if (todate == null || todate == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("choose date");
				flag=false;
			}
			return flag;
		});
		</script>



	
	<?php include '../php_includes/footer.php'?>
</body>

</html>