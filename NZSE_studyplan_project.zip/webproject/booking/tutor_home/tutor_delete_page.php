<?php include '../php_includes/check_session_tutor_and_html.php'; ?>
<head>
	<?php $title="delete schedule"; ?>
	<?php include '../php_includes/head_elements.php' ?>
</head>
	
	
<body>
<?php include "../php_includes/header_elements.php"; ?>
	<br><div id='error'>
		<?php
				if(isset($_SESSION['error']))
				{	
					print $_SESSION['error'];
					unset($_SESSION['error']);
				}
		?>
</div><!--error--><br />
	<div class="tables">
	
	<!--delete code-->
	<?php
	include '../php_script/connectDB.php';
	if(isset($_POST['rid']))
		{
			$_SESSION['id']=$_POST['rid'];
		echo "<h2 id='delete_check'>Are You Sure?</h2><br>";
		echo "<form id='delete_button' action='./tutor_delete_page.php' method='post'><input type='submit' value='Yes' name='yes'> <input type='submit' value='No' name='no'></form>";
		}
		if(isset($_POST['yes']))
		{
			
			$query="DELETE FROM resit WHERE resitid='".$_SESSION['id']."'";
			if($result=mysqli_query($conn,$query))
			{
			$_SESSION['error'] = "deleted successfully";
			header('location: ./tutor_delete_page.php');
			exit();
			}
		}
		if(isset($_POST['no']))
		{
			header('location: ./tutor_delete_page.php');
			exit();
		}
		echo"<br>";
		mysqli_close($conn);
		?>
		<!--table code-->
		<?php 
	$studentid = $_SESSION['studentid'];
	
		include '../php_script/connectDB.php';
		
		$result = "SELECT assessment.title, resit.resitid,assessment.number,courses.moduleid,assessment.type,courses.modulename, resit.comment,resit.comment2,resit.comment3, resit.studyhours, resit.date, resit.time FROM resit INNER JOIN assessment ON assessment.assessmentid=resit.assessmentid INNER JOIN courses 
			ON assessment.moduleid=courses.moduleid WHERE resit.studentid='".$studentid."'";	
		if ($runquery = $conn->query($result))
		{
			while($row = $runquery->fetch_assoc())
			{
			$time=rtrim($row['time'],':0');
			
			echo " <table class='border'>";
			echo "<tr><th colspan='4' width='70%'><b>" . $row['moduleid'] . ".</b> ".$row['modulename']."</th><th width='30%'>check</th></tr>";
			echo "<tr><td colspan='5' width='100%'>".$row['number']."-" . $row['title'] ." (". $row['type'].")</td></tr>";
			echo "<tr><td colspan='2'>Due Date: " . $row['date'] . "</td><td colspan='2'>Time: ".$time."</td><td>THS: " . $row['studyhours'] . "</td></tr>";
			echo "<tr>";
			if($row['comment']!="") 
			{
			echo "<td class='comment' colspan='5'><ul><li>" . $row['comment'] . "</li>";
			if($row['comment2']!="")
			{
			echo "<li>".$row['comment2']."</li>";
			if($row['comment3']!="")
			{
			echo "<li>".$row['comment3']."</li></ul></td>";
			}
			else{echo "</ul></td>";}
			}
			else
			{
				echo "</ul></td>";
			}
			}
			elseif ($row['comment2']!="")
			{
				echo "<td class='comment' colspan='5'><ul><li>" . $row['comment2'] . "</li>";
				if($row['comment3']!="")
				{
					echo "<li>".$row['comment3']."</li></ul></td>";
				}
			}
			elseif ($row['comment3']!="")
			{
				echo "<td class='comment' colspan='5'><ul><li>" . $row['comment3'] . "</li></ul></td>";
			}
			else
			{echo "<td class='comment' colspan='5'></td>";}
			echo "</tr></table><br><form action='./tutor_delete_page.php' method='post'>
			<input class='invi' type='text' name='rid' value='".$row['resitid']."'>
			<input type='submit' value='delete' name='delete' /></form>";
		}
		}
		mysqli_close($conn);
	?>
	<br><br>
	<h3 id="back"><a href = "./tutor_search_schdule_for_delete_page.php">Back</a></h3>
	</div><br><br><br><br><br><br><br>
<?php include '../php_includes/footer.php'?>
</body>

</html>