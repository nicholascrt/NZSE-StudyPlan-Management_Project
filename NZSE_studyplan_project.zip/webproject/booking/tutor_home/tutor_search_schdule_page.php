<?php include '../php_includes/check_session_tutor_and_html.php'; ?>
<head>
	<?php $title="search student's schedule"; ?>
	<?php include '../php_includes/head_elements.php' ?>
	<script src="../js/jquery-1.9.1.js"></script>
<script src="../js/alertify.min.js"></script>
<link rel="stylesheet" href="../css/css_alertboxes/alertify.core.css" />
<link rel="stylesheet" href="../css/css_alertboxes/alertify.default.css" />
</head>
<body>
	<?php include '../php_includes/header_elements.php' ?>
	
<div id="container">
	
<form id="form1" action="./tutor_search_schdule_page.php" method="post" method="post">	
<div id='error'>
		<?php
				if(isset($_SESSION['error']))
				{	
					print $_SESSION['error'];
					if(isset($_SESSION['lead']))
					{
						print $_SESSION['lead'];
					}
					unset($_SESSION['error']);
					unset($_SESSION['lead']);
				}
		?>
	</div><br /><!--error-->
<fieldset>
				<p class="first">
					<label for="studentid">Student id:</label>
		<input type="text" name="studentid" /><br />
				</p>
						
			</fieldset>					

			<p class="submit"><button type="submit" name="submitstudentevent">Submit</button></p>		
						
		</form>	
</div>
<script>
	$("#form1").on('submit', function () 
		{	
			var flag;
			var d = 5000;
			var studentid = document.forms["form1"]["studentid"].value;
			if (studentid == null || studentid == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("pick a student id");
				flag=false;
			}
			
			
			return flag;
		});
		</script>
	<?php include '../php_includes/footer.php'?>
</body>
</html>		
<?php
if (isset($_POST['submitstudentevent'])){
	include '../php_script/connectDB.php';

$studentid = trim($_POST['studentid']);


if (empty($studentid))
{
	$_SESSION['error']="Please fill in all fields";
	header('location: ./tutor_search_schdule_page.php'); 
	exit();
}
$query = "SELECT COUNT(*) as cnt FROM userid WHERE userid.id= '".$studentid."'";
$runquery = mysqli_query($conn, ($query));
if($runquery){
$_SESSION["studentid"] = $studentid;


$row = mysqli_fetch_array($runquery); 
$cnt = $row['cnt'];
}
if($cnt < 1)
{
	$_SESSION['error'] = "There is no such student id.";
	$_SESSION['lead'] = "<br><a href='./tutor_registerstudent_page.php'>click here to register the student id</a>";
	header('location: ./tutor_search_schdule_page.php'); 
	exit();
 } 

 header('location: ../php_script/tutor_view_student_event.php');
 mysqli_close($conn);
}
 ?>