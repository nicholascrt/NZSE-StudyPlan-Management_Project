<?php include '../php_includes/check_session_tutor_and_html.php'; ?>
<head>
	<?php $title="add module"; ?>
	<?php include '../php_includes/head_elements.php'; ?>
	<script src="../js/jquery-1.9.1.js"></script>
	<script src="../js/alertify.min.js"></script>
	<link rel="stylesheet" href="../css/css_alertboxes/alertify.core.css" />
	<link rel="stylesheet" href="../css/css_alertboxes/alertify.default.css" />
</head>

<body>
<?php include "../php_includes/header_elements.php"; ?>
 
<div id='error'>
		<?php
				if(isset($_SESSION['error']))
				{	
					print $_SESSION['error'];
					unset($_SESSION['error']);
				}
		?>
		</div><!--error--><br />
<div id = "container">
	<form  id="form1" name="module" action="./tutor_create_module_form.php" method="get">  				
			<fieldset>
				<p class="first">
						
							<label for="moduleid" >moduleid</label>
							<input id="moduleid" name="moduleid" type="text" />
						</p>
						<p> 
							<label for="modulename" > modulename</label>
							<input id="modulename" name="modulename" type="text" /> 
						</p>
						</fieldset>
						<p class="submit"> 
							<button name="submit" type="submit" >submit</button> 
						</p>
					</form>
					</div>
	
<script>
		
		$("#form1").on('submit', function () 
		{	
			var flag;
			var d = 5000;
			var moduleid = document.forms["form1"]["moduleid"].value;
			if (moduleid == null || moduleid == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("moduleid must be filled out");
				flag=false;
			}
			
			var modulename = document.forms["form1"]["modulename"].value;
			if (modulename == null || modulename == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("modulename must be filled out.");
				flag=false;
			}
			return flag;
		});
	</script>
	


<?php
if (isset($_GET['submit'])){
include '../php_script/connectDB.php';



$moduleid = trim($_GET['moduleid']);
$modulename = trim($_GET['modulename']);


if (empty($moduleid)||empty($modulename))
{
	$_SESSION['error']="Please fill in all fields";
	header('location: ./tutor_create_module_form.php');
	exit();
}
$query = "SELECT COUNT(*) as cnt FROM courses WHERE moduleid= '".$moduleid."'";
$runquery = mysqli_query($conn, ($query));
$row = mysqli_fetch_array($runquery); 
$cnt = $row['cnt'];

if($cnt >= 1)
{
	$_SESSION['error'] = "The module already exists.";
	header('location: ./tutor_create_module_form.php');
	exit();
 }
 $sql = "INSERT INTO courses(moduleid,modulename) VALUES ('$moduleid','$modulename')";
if ($runquery = $conn->query($sql))
	{
	$_SESSION['error'] = "The module added.";
	header('location: ./tutor_create_module_form.php');
	exit();
	}
	else{
		$_SESSION['error'] = "doesn't work.";
		header('location:./tutor_create_module_form.php');
		exit();
	}
  mysqli_close($conn);
}
?>
	<a id="back" href="./tutor_create_module_page.php">Go back to view modules</a> 
	
<?php include '../php_includes/footer.php'; ?>
</body>
</html>		