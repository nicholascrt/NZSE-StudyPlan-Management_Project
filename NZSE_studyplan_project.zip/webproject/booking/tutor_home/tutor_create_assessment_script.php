<?php
	session_start();
include '../php_script/connectDB.php';
$moduleid = trim($_GET['moduleid']);
$type = trim($_GET['type']);
$title = trim($_GET['title']);
$number = trim($_GET['number']);

if (empty($moduleid)||empty($title)
	||empty($type)||empty($number))
{
	$_SESSION['error']="Please fill in all fields";
	header('location: ./tutor_create_assessment_form.php'); 
	exit();
}
$assessmentid = trim($moduleid.".".$number);
$query = "SELECT COUNT(*) as cnt FROM assessment WHERE assessmentid= '".$assessmentid."'";
$runquery = mysqli_query($conn, ($query));
$row = mysqli_fetch_array($runquery); 
$cnt = $row['cnt'];

if($cnt >= 1)
{
	$_SESSION['error'] = "The assessment already exists.";
	header('location: ./tutor_create_assessment_form.php');
	exit();
 }
 $sql = "INSERT INTO assessment(assessmentid,title,type,moduleid,number)
VALUES ('$assessmentid','$title','$type','$moduleid','$number')";
if ($runquery = $conn->query($sql))
	{
	$_SESSION['error'] = "The assessment added.";
	header('location: ./tutor_create_assessment_form.php');
	exit();
	}
	else{
		$_SESSION['error'] = "doesn't work.";
		header('location:./tutor_create_assessment_form.php');
		exit();
	}
  mysqli_close($conn);
?>