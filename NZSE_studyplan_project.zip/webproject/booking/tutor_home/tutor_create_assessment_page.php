<?php include '../php_includes/check_session_tutor_and_html.php'; ?>
<head>
	<?php $title="view assessment"; ?>
	<?php include '../php_includes/head_elements.php' ?>
</head>
<body>
<?php include "../php_includes/header_elements.php"; ?>
<div id='error'>
		<?php
				if(isset($_SESSION['error']))
				{	
					print $_SESSION['error'];	
					unset($_SESSION['error']);
				}
				
		?>
</div><!--error--><br />
<!--deleting assessments-->
<?php 
include '../php_script/connectDB.php';
if(isset($_GET['id']))
	{
		$_SESSION['id']=$_GET['id'];
		echo "<h2 id='delete_check'>Are You Sure to delete '".$_SESSION['id']."'?</h2><br>";
		echo "<form id='delete_button' action='./tutor_create_assessment_page.php' method='post'><input type='submit' value='Yes' name='yes'> <input type='submit' value='No' name='no'></form>";
	}
	if(isset($_POST['yes']))
	{
		$query="DELETE FROM assessment WHERE assessmentid='".$_SESSION['id']."'";
		if($result=mysqli_query($conn,$query))
		{
			$_SESSION['error'] = "deleted.";
			header('location: ./tutor_create_assessment_page.php');
				exit();
		}
	}
	if(isset($_POST['no']))
	{	
		header('location: ./tutor_create_assessment_page.php');
				exit();
	}
	mysqli_close($conn);
	?>
	<!--listing assessments-->
	<?php
	include '../php_script/connectDB.php';
	$query="SELECT assessmentid,title FROM assessment ORDER BY assessmentid";
	$result=mysqli_query($conn,$query);
	echo "<div id='list'><ul>";
	while($row=mysqli_fetch_assoc($result))
	{
		$assessmentid=$row['assessmentid'];
	echo "<li><h4>".$assessmentid."</h4>&emsp;&emsp; ".$row['title']." | <a href='./tutor_create_assessment_page.php?id=$assessmentid'>delete</a></li><br>";
	}
	echo "</ul></div>";
	mysqli_close($conn);
	?>

	<br>
	<a id="back" href="./tutor_create_assessment_form.php">go to create new</a>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	<?php include '../php_includes/footer.php'?>

</body>
</html>		