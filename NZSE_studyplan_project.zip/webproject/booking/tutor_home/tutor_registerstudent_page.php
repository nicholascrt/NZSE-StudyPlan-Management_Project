<?php include '../php_includes/check_session_tutor_and_html.php'; ?>

<head>
	<?php $title="register student"; ?>
	<?php include '../php_includes/head_elements.php' ?>
	<script src="../js/jquery-1.9.1.js"></script>
<script src="../js/alertify.min.js"></script>
<link rel="stylesheet" href="../css/css_alertboxes/alertify.core.css" />
<link rel="stylesheet" href="../css/css_alertboxes/alertify.default.css" />
</head>

<body>
	<?php include '../php_includes/header_elements.php' ?>
<?php
if (isset($_POST['submitregi'])){
include '../php_script/connectDB.php';

$studentid = $_POST['student_id'];
$studentname = $_POST['student_name'];
$email = $_POST['email_student'];
$password = md5("P@ssw0rd");

if(empty($studentid)||empty($studentname))
{	
	$_SESSION["error"] = "Please fill in all fields.";
	header('location: ./tutor_registerstudent_page.php'); 
	exit();
}
if (!preg_match('/^i[0-9]{6}$/', $studentid)) 
	{
		$_SESSION['error']="Invailded student id format, please try again.";
		header('location: ./tutor_registerstudent_page.php'); 
		exit();
	}
	
if (!preg_match('/^[a-z]*.[a-z]*$/', $studentname)) 
	{
		$_SESSION['error']="Invailded name format, please try again.";
		header('location: ./tutor_registerstudent_page.php'); 
		exit();
	}
	
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
{
	$_SESSION['error']="Invailded email, please try again.";
	header('location: ./tutor_registerstudent_page.php'); 
	exit();
}
$sql = "INSERT INTO userid(id,username,password,email)
VALUES ('$studentid', '$studentname', '$password','$email')";

if ($conn->query($sql) === TRUE)
{
	$_SESSION['error']="Student added successfully.";
} 
else 
{
	$_SESSION['error']="Student ID is already existed, please try again.";
}
    header('location: ./tutor_registerstudent_page.php');
	exit();
}
?>
	<div id='chgpw_form'>

	<div id='error'>
		<?php
				if(isset($_SESSION['error']))
				{	
					print $_SESSION['error'];
					unset($_SESSION['error']);
				}
		?>
	</div><!--error-->
		<div id="container">			
		<form id="form1" action="./tutor_registerstudent_page.php" method="post">	
		
	<fieldset>
			<legend>Contact form</legend>
				<p class="first">
					<label>Student ID:</label>
		<input type='text' name='student_id'><br />
				</p>
				<p>
					<label>Student Name:</label>
		<input type='text' name='student_name'><br />
				</p>
				<p>
					<label>Email:</label>
		<input type='text' name='email_student'><br />	
				</p>
				</fieldset>		

			<p class="submit"><button type="submit" name='submitregi'>Register</button></p>		
						
		</form>	
</div>
	</div><!--chgpw_form-->
	<script>
	$("#form1").on('submit', function () 
		{	
			var flag;
			var d = 5000;
			var student_id = document.forms["form1"]["student_id"].value;
			if (student_id == null || student_id == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("fill student id");
				flag=false;
			}
			var student_name = document.forms["form1"]["student_name"].value;
			if (student_name == null || student_name == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("fill student name");
				flag=false;
			}
			var email_student = document.forms["form1"]["email_student"].value;
			if (email_student == null || email_student == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("fill email of the student");
				flag=false;
			}
			return flag;
		});
		</script>
		<?php include '../php_includes/footer.php'?>
	
</body>
</html>