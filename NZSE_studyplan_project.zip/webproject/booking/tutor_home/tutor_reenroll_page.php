<?php include '../php_includes/check_session_tutor_and_html.php'; ?>
<head>
	<?php $title="create re-enroll"; ?>
	<?php include '../php_includes/head_elements.php' ?>
	<script src="../js/jquery-1.9.1.js"></script>
<script src="../js/alertify.min.js"></script>
<link rel="stylesheet" href="../css/css_alertboxes/alertify.core.css" />
<link rel="stylesheet" href="../css/css_alertboxes/alertify.default.css" />
</head>
<body>
	<?php include '../php_includes/header_elements.php' ?>
<div id='error'>
<?php
				if(isset($_SESSION['error']))
				{	
					print $_SESSION['error'];
					if(isset($_SESSION['lead']))
					{
						print $_SESSION['lead'];
					}
					unset($_SESSION['error']);
					unset($_SESSION['lead']);
				}
?>
	</div><br /><!--error-->
<div id = "container">
	<form id="form1" action="./tutor_reenroll_script.php" method="post">	

			<fieldset>
				<p class="first">
					<label for="studentid">Student id:</label>
					<input type="text" name="studentid" /><br />
				</p>
				<p>
					<label for="cohort">Cohort:</label>
	<input type="text" name="cohort" /><br />
				</p>
		
				<?php include '../php_script/getModuleForm_script.php'?>
				
				<p>
				<label for="date">Start date:</label>
	<input type="date" name="startdate" value="start-date" /><br />
				</p>

				<p>
					<label for="date">End date:</label>
	<input type="date" name="enddate" value="end-date" /><br />
				</p>

<p>
					<label for="time">Class time:</label>
	<input type="text" name="classtime" /><br />
				</p>

<p>
					<label for="time">Lab time:</label>
	<input type="text" name="labtime" /><br />
				</p>


			</fieldset>
			<fieldset>																			
				<p>
					<label for="text">Comment:</label>
	<textarea name="comment" rows="3" cols="40"></textarea>
				</p>

<p>
					<label for="text">Comment:</label>
	<textarea name="comment2" rows="3" cols="40"></textarea>
				</p>	

<p>
					<label for="text">Comment:</label>
	<textarea name="comment3" rows="3" cols="40"></textarea>
				</p>					
			</fieldset>					

			<p class="submit"><button type="submit" name="submitenroll">Submit</button></p>		
						
		</form>	
</div>
<script>
	$("#form1").on('submit', function () 
		{	
			var flag;
			var d = 5000;
			var studentid = document.forms["form1"]["studentid"].value;
			if (studentid == null || studentid == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("studentid must be filled out");
				flag=false;
			}
			var cohort = document.forms["form1"]["cohort"].value;
			if (cohort == null || cohort == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("cohort must be filled out.");
				flag=false;
			}
			var moduleid = document.forms["form1"]["moduleid"].value;
			if (moduleid == null || moduleid == "Select a module") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("moduleid must be filled out");
				flag=false;
			}
				var startdate = document.forms["form1"]["startdate"].value;
			if (startdate == null || startdate == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("startdate must be filled out.");
				flag=false;
			}
			var enddate = document.forms["form1"]["enddate"].value;
			if (enddate == null || enddate == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("enddate must be filled out.");
				flag=false;
			}
			var classtime = document.forms["form1"]["classtime"].value;
			if (classtime == null || classtime == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("classtime must be filled out.");
				flag=false;
			}
			var labtime = document.forms["form1"]["labtime"].value;
			if (labtime == null || labtime == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("labtime must be filled out.");
				flag=false;
			}
			return flag;
		});
</script><br><br><br><br><br><br>
<?php include '../php_includes/footer.php';?>
</body>
</html>	
<script src="http://www.google-analytics.com/urchin.js" type="text/javascript">
</script>
<script type="text/javascript">
_uacct = "UA-783567-1";
urchinTracker();
</script>
