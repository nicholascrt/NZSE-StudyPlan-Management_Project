<?php include '../php_includes/check_session_tutor_and_html.php'; ?>
<head>
	<?php $title="change password"; ?>
	<?php include '../php_includes/head_elements.php' ?>
	<script src="../js/jquery-1.9.1.js"></script>
<script src="../js/alertify.min.js"></script>
<link rel="stylesheet" href="../css/css_alertboxes/alertify.core.css" />
<link rel="stylesheet" href="../css/css_alertboxes/alertify.default.css" />
</head>

<body>
<?php include "../php_includes/header_elements.php"; ?>

<?php
if (isset($_POST['submitchg'])){
include '../php_script/connectDB.php';
//Create the query

$userid = $_SESSION['userid'];
$currpw= md5($_POST['currpw']);
$confirmpassword = $_POST['confirmpasswd'];
$newpassword = $_POST['newpasswd'];

$querysel = "SELECT * FROM userid WHERE id= '".$userid."'";

$runquerysel = mysqli_query($conn, $querysel);

if(empty($confirmpassword)||empty($newpassword)||empty($currpw))
{	
	$_SESSION["error"] = "Please fill in all fields.";
	header('location: ./tutor_changepw_page.php'); 
	exit();
}

while($row = mysqli_fetch_assoc($runquerysel)) 
{
 if($userid == $row['id'] && $currpw == $row['password'])
 {
		if ($newpassword!= $confirmpassword)
		{
			$_SESSION['error']="Password and confirm password not match.";
		}
		else{
			$newpassword=md5($newpassword);
			$queryupdate = "UPDATE userid SET password='$newpassword' WHERE id='$userid' ";
			$runqueryupdate = mysqli_query($conn, $queryupdate);
			if($runqueryupdate) 
			{
				$_SESSION['error'] = "Password has been udpated";
			}
			else
			{
				$_SESSION['error'] = "Password has not been udpated";
			}
		}
 }
else{
	$_SESSION['error']="Current password is not correct, please try again.";
 }
 	header('location: ./tutor_changepw_page.php');
	exit();
}
}
?>
	<div id='error'>
		<?php
				if(isset($_SESSION['error']))
				{	
					print $_SESSION['error'];
					unset($_SESSION['error']);
				}
		?>
	</div><!--error-->
		<div id="container">
		<form id="form1" action='./tutor_changepw_page.php' method="post">
		<fieldset><p class="first">
		<label>Current password:</label>
		<input type='password' name='currpw'><br />
		</p>
		
		<p>
		<label>New password:</label>
		<input type='password' name='newpasswd'><br />
		</p>
		
		<p>
		<label>Confirm password:</label>
		<input type='password' name='confirmpasswd'><br />
		</p>
			</fieldset>
		<p class="submit"><button type="submit" name='submitchg'>Change Password</button></p>	
		
		</form>

		</div><!--container-->
		<script>
	$("#form1").on('submit', function () 
		{	
			var flag;
			var d = 5000;
			var currpw = document.forms["form1"]["currpw"].value;
			if (currpw == null || currpw == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("fill in current password");
				flag=false;
			}
			var newpasswd = document.forms["form1"]["newpasswd"].value;
			if (newpasswd == null || newpasswd == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("fill in new password");
				flag=false;
			}
			var confirmpasswd = document.forms["form1"]["confirmpasswd"].value;
			if (confirmpasswd == null || confirmpasswd == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("fill in confirm password");
				flag=false;
			}
			if (confirmpasswd !== newpasswd) 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("passwords do not match");
				flag=false;
			}
			if (currpw === newpasswd && currpw === confirmpasswd) 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("you should have a new password");
				flag=false;
			}
			return flag;
		});
		</script>
	<?php include '../php_includes/footer.php'?>
	
	
</body>
</html>