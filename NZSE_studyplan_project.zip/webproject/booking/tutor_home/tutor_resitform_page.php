<?php include '../php_includes/check_session_tutor_and_html.php'; ?>
<head>
<?php $title="create resit"; ?>
<?php include '../php_includes/head_elements.php' ?>
<script src="../js/jquery-1.9.1.js"></script>
<script src="../js/alertify.min.js"></script>
<link rel="stylesheet" href="../css/css_alertboxes/alertify.core.css" />
<link rel="stylesheet" href="../css/css_alertboxes/alertify.default.css" />
	<script>
function showModule(str) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("txtHint1").innerHTML = xmlhttp.responseText;
            }
        }
        xmlhttp.open("GET","../php_script/getAssessmentForm_script.php?moduleId="+str,true);
        xmlhttp.send();
    } 
</script>
</head>

<body>
<?php include "../php_includes/header_elements.php"; ?>

 

<div id='error'>
		<?php
				if(isset($_SESSION['error']))
				{	
					print $_SESSION['error'];
					if(isset($_SESSION['lead']))
					{
						print $_SESSION['lead'];
					}
					unset($_SESSION['error']);
					unset($_SESSION['lead']);
				}
				
		?>
</div><!--error--><br />
	
	<div id = "container">
	<form id="form1" name="resit" action="./tutor_resitform_script.php" method="post">	

	<fieldset>
				<p class="first">
					<label for="studentid">Student id:</label>
	<input type="text" name="studentid" /><br />
				</p>
				<p>
					<label for="cohort">Cohort:</label>
	<input type='text' name='cohort' >
				</p>
				<?php include '../php_script/getModuleForm_script.php'?>
				
				<label id="txtHint1">Assessment:</label><br />
				<p>
					<label for="studyhours">Study hours:</label>
	<input type="text" name="studyhours"/><br />
				</p>	

	<p>
					<label for="date">Date:</label>
	<input type="date" name="date"/><br />	
				</p>	

	<p>
					<label for="time">Time:</label>
	<input type="time" name="time"/><br />
				</p>	

	
			</fieldset>
			<fieldset>																			
				<p>
					<label for="text">Comment:</label>
	<textarea name="comment" rows="3" cols="40"></textarea>
				</p>
				<p>
					<label for="text">Comment:</label>
	<textarea name="comment2" rows="3" cols="40"></textarea>
				</p>	
				<p>
					<label for="text">Comment:</label>
	<textarea name="comment3" rows="3" cols="40"></textarea>
				</p>					
			</fieldset>					

			<p class="submit"><button type="submit" name="submitresit" >Submit</button></p>		
						
		</form>	
		</div>
	
 
<script>
	$("#form1").on('submit', function () 
		{	
			var flag;
			var d = 5000;
			var moduleid = document.forms["form1"]["moduleid"].value;
			if (moduleid == null || moduleid == "Select a module") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("moduleid must be filled out");
				flag=false;
			}
			
			var studentid = document.forms["form1"]["studentid"].value;
			if (studentid == null || studentid == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("studentid must be filled out");
				flag=false;
			}
			
			var studyhours = document.forms["form1"]["studyhours"].value;
			if (studyhours == null || studyhours == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("studyhours must be filled out.");
				flag=false;
			}
			var date = document.forms["form1"]["date"].value;
			if (date == null || date == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("date must be filled out.");
				flag=false;
			}
			var time = document.forms["form1"]["time"].value;
			if (date == null || date == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("time must be filled out.");
				flag=false;
			}
			var cohort = document.forms["form1"]["cohort"].value;
			if (cohort == null || cohort == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("cohort must be filled out.");
				flag=false;
			}
			return flag;
		});
</script>

	<br><br><br><br><br><br>
	<?php include '../php_includes/footer.php'?>
</body>
</html>		