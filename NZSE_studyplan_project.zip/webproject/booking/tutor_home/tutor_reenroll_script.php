<?php
	session_start();
	include '../php_script/connectDB.php';

$studentid = trim($_POST['studentid']);
$cohort = trim($_POST['cohort']);
$moduleid = trim($_POST['moduleid']);
$startdate = trim($_POST['startdate']);
$enddate = trim($_POST['enddate']);
$classtime = trim($_POST['classtime']);
$labtime = trim($_POST['labtime']);
$comment = trim($_POST['comment']);
$comment2 = trim($_POST['comment2']);
$comment3 = trim($_POST['comment3']);

if (empty($studentid)||empty($cohort)||empty($moduleid)||empty($startdate)
	||empty($enddate)||empty($classtime)||empty($labtime))
{
	$_SESSION['error']="Please fill in all fields";
	header('location: ./tutor_reenroll_page.php'); 
	exit();
}
$query = "SELECT COUNT(*) as cnt FROM userid WHERE userid.id= '".$studentid."'";
$runquery = mysqli_query($conn, ($query));
if($runquery){
$_SESSION["studentid"] = $studentid;
$_SESSION["cohort"] =$cohort;
$_SESSION["moduleid"] =$moduleid;
$_SESSION["startdate"] =$startdate;
$_SESSION["enddate"] =$enddate;
$_SESSION["classtime"] =$classtime;
$_SESSION["labtime"] =$labtime;
$_SESSION["comment"] =$comment;
$_SESSION["comment2"] =$comment2;
$_SESSION["comment3"] =$comment3;

$row = mysqli_fetch_array($runquery); 
$cnt = $row['cnt'];
}
if($cnt < 1)
{
	$_SESSION['error'] = "There is no such student id.";
	$_SESSION['lead'] = "<br><a href='./tutor_registerstudent_page.php'>click here to register the student id</a>";
	header('location: ./tutor_reenroll_page.php'); 
	exit();
 } 
 header('location: ../php_script/tutor_confirmenroll_script.php');
 mysqli_close($conn);
