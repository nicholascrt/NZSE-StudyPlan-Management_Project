<?php include '../php_includes/check_session_tutor_and_html.php'; ?>
<head>
	<?php $title="view request"; ?>
	<?php include '../php_includes/head_elements.php' ?>
	<script>
	function myFunction() {
    window.print();}
	</script>
</head>
<body>
<?php include '../php_includes/header_elements.php' ?>
	<div class="tables">
	<div class="print">
		<button onclick="myFunction()">Print this page</button>
	</div><!--print-->
	<?php
	include '../php_script/connectDB.php';
		$result = "SELECT userid.username, userid.id, studentresitrequest.studentID, studentresitrequest.cohort, assessment.title, courses.modulename, studentresitrequest.comment,
		studentresitrequest.date, studentresitrequest.time
		FROM userid 
		INNER JOIN studentresitrequest 
		ON userid.id=studentresitrequest.studentID 
		INNER JOIN assessment 
		ON assessment.assessmentid=studentresitrequest.assessmentid 
		INNER JOIN courses 
		ON assessment.moduleid=courses.moduleid";		
		echo" ";
		echo"<h1>STUDENT REQUEST</h1>";
		echo "<table>
		<tr>
		<th>Student ID</th>
		<th>Student Name</th>
		<th>Cohort</th>
		<th>ModuleName</th>
		<th>Assesment Title</th>
		<th>Assessment due date</th>
		<th>Comment</th>
		<th>Prove</th>		
		</tr>";

		if ($runquery = $conn->query($result))
	{
		$count=0;
		$_SESSION['proved']=0;
		while($row = $runquery->fetch_assoc())
		{
			$count++;
			echo "<tr><form action='./tutor_resitform_page.php' method='post'>";
			echo "<td style='width:9%'>" . $row['studentID']."</td>";
			echo "<td style='width:9%'>" . $row['username']."</td>";
			echo "<td style='width:9%'>" . $row['cohort']."</td>";
			echo "<td style='width:9%'>" . $row['modulename'] ."</td>";
			echo "<td style='width:9%'>" . $row['title']."</td>";
			echo "<td style='width:9%'>" . $row['date'] . "<br>".$row['time']."</td>";
			if($row['comment']!="") 
			{
				echo "<td><ul><li>" . $row['comment'] . "</li>";
				echo "</ul></td>";
			}
			else
			{
				echo "<td></td>";
			}
			echo "<td style='width:9%'><input id='cnt' type='text' name='cnt' value="; echo $count."><input type='submit' name='Prove' value='approve'></td></form></tr>";
		}
	}
		echo "</table>";
		echo"<br>";
		mysqli_close($conn);
		echo" ";
	?>
	<a href = "../tutor_home/tutor_page.php">Back</a>
	 
	<br />
<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
	<?php include '../php_includes/footer.php'?>

</body>

</html>