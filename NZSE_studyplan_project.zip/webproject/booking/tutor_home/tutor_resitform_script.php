<?php
	session_start();
include '../php_script/connectDB.php';

$studentid = trim($_POST['studentid']);
$cohort = trim($_POST['cohort']);
$assessmentid = trim($_POST['assessmentid']);
$moduleid = trim($_POST['moduleid']);
$studyhours = trim($_POST['studyhours']);
$date = trim($_POST['date']);
$time = trim($_POST['time']);
$comment = trim($_POST['comment']);
$comment2 = trim($_POST['comment2']);
$comment3 = trim($_POST['comment3']);


if (empty($studentid)||empty($cohort)||empty($assessmentid)
	||empty($date)||empty($time)||empty($studyhours))
{
	$_SESSION['error']="Please fill in all fields";
	header('location: ./tutor_resitform_page.php'); 
	exit();
}

$query = "SELECT COUNT(*) as cnt FROM userid WHERE userid.id= '".$studentid."'";
$runquery = mysqli_query($conn, ($query));
if($runquery){
$_SESSION["studentid"] = $studentid;
$_SESSION["cohort"] =$cohort;
$_SESSION["moduleid"] =$moduleid;
$_SESSION["assessmentid"] =$assessmentid;
$_SESSION["studyhours"] =$studyhours;
$_SESSION["date"] =$date;
$_SESSION["time"] =$time;
$_SESSION["comment"] =$comment;
$_SESSION["comment2"] =$comment2;
$_SESSION["comment3"] =$comment3;
$row = mysqli_fetch_array($runquery); 
$cnt = $row['cnt'];
}
if($cnt < 1)
{
	$_SESSION['error'] = "There is no such student id.";
	$_SESSION['lead'] = "<br><a href='./tutor_registerstudent_page.php'>click here to register the student id</a>";
	header('location: ./tutor_resitform_page.php'); 
	exit();
 } 
	header('location: ../php_script/tutor_confirmresit_script.php');
  mysqli_close($conn);
?>