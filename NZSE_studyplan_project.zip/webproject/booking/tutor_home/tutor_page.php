<?php include '../php_includes/check_session_tutor_and_html.php'; ?>
<head>
	<?php $title="tutor home"; ?>
	<?php include '../php_includes/head_elements.php' ?>
</head>
<body>
		<?php include '../php_includes/header_elements.php' ?>
	<?php include '../php_includes/footer.php'?>
</body>
</html>
				