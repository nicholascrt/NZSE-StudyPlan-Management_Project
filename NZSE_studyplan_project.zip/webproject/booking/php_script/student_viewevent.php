<?php session_start()?>
<!DOCTYPE html>
<html>
<head>
	<?php $title="view event"; ?>
	<?php include '../php_includes/head_elements.php'; ?>
</head>
		
<body>
<?php include '../php_includes/header_elements.php'; ?>
<?php include '../php_includes/print_icon.php'; ?>
<script>
	function myFunction() {
    window.print();}
</script>
 <div class="tables">
	<?php
	$studentid = $_SESSION['userid'];
	
	include '../php_script/connectDB.php';
			
		
		$result = "SELECT assessment.title, courses.modulename, resit.comment,resit.comment2,resit.comment3, resit.studyhours, resit.date, resit.time FROM resit INNER JOIN assessment ON assessment.assessmentid=resit.assessmentid INNER JOIN courses 
			ON assessment.moduleid=courses.moduleid WHERE resit.studentid='".$studentid."'";	
		echo"<h1>ACTION PLAN</h1>";
		echo "<table id='student_resit' class='border'>
		<tr>
		<th>Assesment Title</th>
		<th colspan='2'>Tasks to be completed prior assessment duedate</th>
		<th>Assessment due date</th>			
		</tr>";
		if ($runquery = $conn->query($result))
		{
			while($row = $runquery->fetch_assoc())
			{
				echo "<tr>";
				echo "<td><b>" . $row['modulename'] . "</b><br>".$row['title']."</td>";
				if($row['comment']!="") 
				{
					echo "<td><ul><li>" . $row['comment'] . "</li>";
					if($row['comment2']!="")
					{
						echo "<li>".$row['comment2']."</li>";
						if($row['comment3']!="")
						{
							echo "<li>".$row['comment3']."</li></ul></td>";
						}
						else{echo "</ul></td>";}
					}
					else
					{
						echo "</ul></td>";
					}
				}
				elseif ($row['comment2']!="")
				{
					echo "<td><ul><li>" . $row['comment2'] . "</li>";
					if($row['comment3']!="")
					{
						echo "<li>".$row['comment3']."</li></ul></td>";
					}
				}
				elseif ($row['comment3']!="")
				{
					echo "<td><ul><li>" . $row['comment3'] . "</li></ul></td>";
				}
				else
				{echo "<td></td>";}
				echo "<td>THS: " . $row['studyhours'] . "</td>";
				echo "<td>" . $row['date'] . "<br>".$row['time']."</td>";
				echo "</tr>";
			}
		}
		echo "</table>";
		echo"<br>";
		mysqli_close($conn);
		include './student_viewre-enroll.php';
		echo"<br>";
	?>
	</div><!--tables-->
	<br><br><br>
	<a id="back" href = "../student_home/student_page.php">Back</a>
	 
	<br /><br><br><br><br><br><br><br><br><br><br><br>
	<?php include '../php_includes/footer.php'?>
</body>

</html>