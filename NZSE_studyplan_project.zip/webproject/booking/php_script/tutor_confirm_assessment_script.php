<?php session_start(); ?>
<html>
<body>
	<?php
	$moduleid = $_SESSION['moduleid'];
	
	$con = mysql_connect("localhost:3306","root","");
		if(!$con)
		{
			die('Could not connect!!!!!!');
		}

		mysql_select_db("testdb",$con);
	$result = mysql_query("SELECT courses.modulename 
	FROM courses 
	WHERE moduleid='".$moduleid."'");
if (!$result) {
    die('Invalid query: ' . mysql_error());
}

	while($row = mysql_fetch_assoc($result))
	{
    $modulename = $row['modulename'];
	}
	
	echo"<h1>moduleid: ".$_SESSION["moduleid"]."</h1>";
	echo"<h1>modulename: ".$modulename."</h1>";
	echo"<h1>assessmentid: ".$_SESSION["assessmentid"]."</h1>";
	echo"<h1>title: ".$_SESSION["title"]."</h1>";
	echo"<h1>type: ".$_SESSION["type"]."</h1>";
	echo"<h1>number: ".$_SESSION["number"]."</h1>";	
	mysql_close($con);
	?>
	<form action="./tutor_confirm_assessment_script.php" method="post">
	<h1>are you sure add the record to assessment table?</h1>
	<input type="submit" name="submitassessment" value="submit"/>
	</form>
	<a id="back" href = "../tutor_home/tutor_create_assessment_page.php">Back</a>
</body>
</html>
<?php
if (isset($_POST['submitassessment'])){
	$con = mysql_connect("localhost:3306","root","");
		if(!$con)
		{
			die('Could not connect!!!!!!');
		}
		
		
		mysql_select_db("testdb",$con);
$moduleid = $_SESSION['moduleid'];
$assessmentid = $_SESSION['assessmentid'];
$title = $_SESSION['title'];
$type = $_SESSION['type'];
$number = $_SESSION['number'];

$sql = mysql_query("INSERT INTO assessment(moduleid,assessmentid,title,type,number)
VALUES ('$moduleid','$assessmentid','$title','$type','$number')");

if(!$sql)
{
	$_SESSION['error']= "Doesnt work";
header('location:../tutor_home/tutor_create_assessment_page.php');
exit();
}
else{
	$_SESSION['error']= "assessment added sucessfully";
	header('location:../tutor_home/tutor_create_assessment_page.php');
	exit();
}
mysql_close($con);
}
?>