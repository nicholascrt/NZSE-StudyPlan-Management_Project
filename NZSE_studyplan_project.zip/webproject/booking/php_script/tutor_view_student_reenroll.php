
	<?php
	$studentid = $_SESSION['studentid'];
	$count=$_SESSION['table_count'];
		include '../php_script/connectDB.php';
		
		$result = "SELECT courses.modulename, reenrollment.moduleid,reenrollment.comment,reenrollment.comment2,reenrollment.comment3, reenrollment.cohort, reenrollment.startdate, reenrollment.classtime,reenrollment.labtime,reenrollment.enddate FROM reenrollment INNER JOIN courses ON reenrollment.moduleid
		=courses.moduleid WHERE reenrollment.studentid='".$studentid."'";
		if ($runquery = $conn->query($result))
		{
		while($row = $runquery->fetch_assoc())
		{
			$count++;
			if($count > 4)
			{echo "<div class='gap'></div>";$count=0;}
			echo " <table class='border_enroll'>";
			echo "<tr><th colspan='3'><b>" . $row['moduleid'] . "</b>. ".$row['modulename']."</th></tr>";
			echo "<tr><td colspan='2'>" . $row['cohort'] ."</td><td>Start: " . $row['startdate'] . "</td></tr>";
			echo "<tr><td colspan='2'>Class Time: " . $row['classtime'] . "</td><td>End: ".$row['enddate']."</td></tr>";
			echo "<tr>";
			if($row['comment']!="") 
			{
			echo "<td class='comment' colspan='3'><ul><li>" . $row['comment'] . "</li>";
			if($row['comment2']!="")
			{
			echo "<li>".$row['comment2']."</li>";
			if($row['comment3']!="")
			{
			echo "<li>".$row['comment3']."</li></ul></td>";
			}
			else{echo "</ul></td>";}
			}
			else
			{
				echo "</ul></td>";
			}
			}
			elseif ($row['comment2']!="")
			{
				echo "<td class='comment' colspan='3'><ul><li>" . $row['comment2'] . "</li>";
				if($row['comment3']!="")
				{
					echo "<li>".$row['comment3']."</li></ul></td>";
				}
			}
			elseif ($row['comment3']!="")
			{
				echo "<td class='comment' colspan='3'><ul><li>" . $row['comment3'] . "</li></ul></td>";
			}
			else
			{echo "<td class='comment' colspan='3'></td>";}
			echo "</tr></table> <br>";
			}
			
		}
			
		mysqli_close($conn);
	?>