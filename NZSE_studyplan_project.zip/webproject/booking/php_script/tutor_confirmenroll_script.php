<?php include '../php_includes/check_session_tutor_and_html.php'; ?>
<head>
<?php $title="confirm re-enroll"; ?>
<?php include '../php_includes/head_elements.php'; ?>
</head>
<body>
<?php include '../php_includes/header_elements.php' ?>
	<?php
	$moduleid = $_SESSION['moduleid'];
	
	include '../php_script/connectDB.php';
	$result = "SELECT modulename FROM courses WHERE moduleid='".$moduleid."'";
	if ($runquery = $conn->query($result))
	{
		while($row = $runquery->fetch_assoc())
		{
			$modulename = $row['modulename'];
		}
	}
	echo"<h3 class='confirm_content'>studentid: ".$_SESSION["studentid"]."</h3>";
	echo"<h3 class='confirm_content'>cohort: ".$_SESSION["cohort"]."</h3>";
	echo"<h3 class='confirm_content'>moduleid: ".$_SESSION["moduleid"]."</h3>";
	echo"<h3 class='confirm_content'>modulename: ".$modulename."</h3>";
	echo"<h3 class='confirm_content'>startdate: ".$_SESSION["startdate"]."</h3>";
	echo"<h3 class='confirm_content'>enddate: ".$_SESSION["enddate"]."</h3>";
	echo"<h3 class='confirm_content'>classtime: ".$_SESSION["classtime"]."</h3>";
	echo"<h3 class='confirm_content'>labtime: ".$_SESSION["labtime"]."</h3>";
	echo"<h3 class='confirm_content'>comment </h3>";
	if($_SESSION["comment"]!="") 
		{
		echo "<ul><li class='confirm_comment'>" . $_SESSION["comment"] . "</li>";
		if($_SESSION["comment2"]!="")
		{
		echo "<li class='confirm_comment'>".$_SESSION["comment2"]."</li>";
		if($_SESSION["comment3"]!="")
		{
		echo "<li class='confirm_comment'>".$_SESSION["comment3"]."</li></ul>";
		}
		else{echo "</ul>";}
		}
		else
		{
				echo "</ul>";
		}
		}
		elseif ($_SESSION["comment2"]!="")
		{
		echo "<ul><li class='confirm_comment'>" . $_SESSION["comment2"] . "</li>";
		if($_SESSION["comment3"]!="")
		{
			echo "<li class='confirm_comment'>".$_SESSION["comment3"]."</li></ul>";
		}
		}
		elseif ($_SESSION["comment3"]!="")
		{
			echo "<ul><li class='confirm_comment'>" . $_SESSION["comment3"] . "</li></ul>";
		}
		else
			{echo "<p class='confirm_comment'>No comment</p>";}
		mysqli_close($conn);
	?>
	<h2 id="confirm_message">Are you sure add the record to Re-enroll table?</h2>
	<div class="float">
	<form action="./tutor_confirmenroll_script.php" method="POST">	
	<input type="submit" name="submitenrollinsert" value="submit"/>
	</form>
	</div>
	<div class="float">
	<a id="back" href = "../tutor_home/tutor_reenroll_page.php">Back</a>
	</div><br><br><br><br><br><br><br>
	<?php include '../php_includes/footer.php';?>
</body>
</html>

<?php
if (isset($_POST['submitenrollinsert'])){
include './connectDB.php';
$enrollmentid  = date("Y-m-d h:i:sa");
$studentid = $_SESSION['studentid'];
$cohort = $_SESSION['cohort'];
$moduleid = $_SESSION['moduleid'];
$startdate = $_SESSION['startdate'];
$enddate = $_SESSION['enddate'];
$classtime = $_SESSION['classtime'];
$labtime = $_SESSION['labtime'];
$comment = $_SESSION['comment'];
$comment2 = $_SESSION['comment2'];
$comment3 = $_SESSION['comment3'];
$sql = "INSERT INTO reenrollment(reenrollmentid,studentid,cohort,moduleid,startdate,enddate,classtime,labtime,comment,comment2,comment3)
VALUES ('$enrollmentid','$studentid','$cohort','$moduleid','$startdate','$enddate','$classtime','$labtime','$comment','$comment2','$comment3')";

if($conn->query($sql)===TRUE)
{
	$_SESSION['error']= "Re-enroll added succssfully";
	header('location:../tutor_home/tutor_reenroll_page.php');
	exit();
}
else{
$_SESSION['error']= "Doesnt work";
header('location:../tutor_home/tutor_reenroll_page.php');
exit();
}
mysqli_close($conn);
}

?>

