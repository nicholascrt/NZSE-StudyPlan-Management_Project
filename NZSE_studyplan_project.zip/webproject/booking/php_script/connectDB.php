 <?php
$server="localhost";
$loginaccount="studyplan";
$loginpasswd="P@ssw0rd";
$dbname="studyplan";
$conn = mysqli_connect($server, $loginaccount, $loginpasswd, $dbname);
if (mysqli_connect_errno())
{
  print "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>