<?php session_start(); ?>
<html>
<head>
<title>Confirm Request</title>
<link rel="stylesheet" href="../css/main_style.css"/>
</head>
<body>
<div id="header"><h2>Confirm Request Resit</h2></div>
<?php include '../php_includes/header_elements.php' ?>

	<?php
	include './connectDB.php';
	$moduleid = $_SESSION['moduleid'];
	$assessmentid=$_SESSION["assessmentid"] ;

	$query = "SELECT a.title, c.modulename
	FROM assessment a, courses c
	WHERE c.moduleid = a.moduleid
	AND c.moduleid = $moduleid
	AND a.assessmentid= $assessmentid ";
		
		$result = mysqli_query($conn, $query);

	
while($row = mysqli_fetch_assoc($result))
	{
		echo "<h3>modulename: " . $row['modulename'] . "</h3>";
		echo "<h3>assessmentname: " . $row['title'] . "</h3>";
	}
		echo"<h3>studentid: ".$_SESSION["studentid"]."</h3>";
		echo"<h3>assessmentid: ".$_SESSION["assessmentid"]."</h3>";
		echo"<h3>cohort: ".$_SESSION["cohort"]."</h3>";
		echo"<h3>date: ".$_SESSION["date"]."</h3>";
		echo"<h3>time: ".$_SESSION["time"]."</h3>";	
		echo"<h3>comment </h3>";
		echo"<ul><li>".$_SESSION["comment"]."</li></ul>";
		
		mysqli_close($conn);
	?>
	
	<form action="./student_requestresitconfirm_script.php" method="post">
	<h2>Do you confirm this resit request?</h2>
	<input type="submit" name="confirmRequest" value="Confirm"/>
	</form>
	<a id="back" href = "../student_home/student_requestresit_page.php">Back</a>
<?php include '../php_includes/footer.php'?>
</body>
</html>
<?php
if (isset($_POST['confirmRequest'])){
	include './connectDB.php';
	$resitid  = date("Y-m-d h:i:sa");
$studentid = $_SESSION['studentid'];
$cohort = $_SESSION['cohort'];
$assessmentid = $_SESSION['assessmentid'];
$date = $_SESSION['date'];
$time = $_SESSION['time'];
$comment = $_SESSION['comment'];
$query = "INSERT INTO studentresitrequest(resitID,studentID,cohort,assessmentID,date,time,comment)
VALUES ('$resitid','$studentid','$cohort','$assessmentid','$date','$time','$comment')";
$runquery=mysqli_query($conn,$query);

if($runquery)
{
	$_SESSION['error']= "Resit requests sucessfully";
	header('location:../student_home/student_requestresit_page.php');
	exit();
}
else{
$_SESSION['error']= "Doesnt work";
header('location:../student_home/student_requestresit_page.php');
exit();
}
}
?>