

	<?php
	$studentid = $_SESSION['userid'];
	
		include '../php_script/connectDB.php';
		
		$result = "SELECT courses.modulename, reenrollment.comment,reenrollment.comment2,reenrollment.comment3, reenrollment.cohort, reenrollment.startdate, reenrollment.classtime,reenrollment.labtime,reenrollment.enddate FROM reenrollment INNER JOIN courses ON reenrollment.moduleid
		=courses.moduleid WHERE reenrollment.studentid='".$studentid."'";
		echo"<div class='page-break'></div><h1>RE-ENROLLMENT</h1>";
		echo "<table id='student_reenroll' class='border_enroll'>
		<tr>
		<th>Course</th>
		<th>Comment</th>
		<th>Term</th>
		<th>Detail</th>
		</tr>";
		if ($runquery = $conn->query($result))
		{
			while($row = $runquery->fetch_assoc())
			{
			echo "<tr>";
			echo "<td>" . $row['cohort'] . "<br>" . $row['modulename'] ."</td>";
			if($row['comment']!="") 
			{
				echo "<td><ul><li>" . $row['comment'] . "</li>";
				if($row['comment2']!="")
				{
					echo "<li>".$row['comment2']."</li>";
					if($row['comment3']!="")
					{
						echo "<li>".$row['comment3']."</li></ul></td>";
					}
					else{echo "</ul></td>";}
				}
				else
				{
					echo "</ul></td>";
				}
			}
			elseif ($row['comment2']!="")
			{
				echo "<td><ul><li>" . $row['comment2'] . "</li>";
				if($row['comment3']!="")
				{
					echo "<li>".$row['comment3']."</li></ul></td>";
				}
			}
			elseif ($row['comment3']!="")
			{
				echo "<td><ul><li>" . $row['comment3'] . "</li></ul></td>";
			}
			else
			{echo "<td></td>";}
			echo "<td>StartDate: " . $row['startdate'] . "<br>EndDate: " . $row['enddate'] . "</td>";
			echo "<td>Classtime: " . $row['classtime'] . "<br>Labtime: ". $row['labtime'] ."</td>";
			echo "</tr>";
		}
		}
		echo "</table>";
		mysqli_close($conn);
	?>
	