<?php include '../php_includes/check_session_tutor_and_html.php'; ?>
<html>
<head>
<?php $title="confirm resit"; ?>
<?php include '../php_includes/head_elements.php'; ?>
</head>
<body>
<?php include '../php_includes/header_elements.php' ?>

	<?php
	$moduleid = $_SESSION['moduleid'];
	$assessmentid = $_SESSION['assessmentid'];
	
	include '../php_script/connectDB.php';
	
	$result = "SELECT courses.modulename, 
	assessment.title FROM assessment 
	INNER JOIN courses on courses.moduleid=assessment.moduleid 
	WHERE assessment.assessmentid='".$assessmentid."'";
	
	if ($runquery = $conn->query($result))
	{
		while($row = $runquery->fetch_assoc())
		{
			$modulename = $row['modulename'];
			$assessmentname = $row['title'];
		}
	}
	
	if (!$runquery) 
	{
		die('Invalid query: ' . mysqli_error());
	}

	
	echo"<h3 class='confirm_content'>studentid: ".$_SESSION["studentid"]."</h3>";
	echo"<h3 class='confirm_content'>cohort: ".$_SESSION["cohort"]."</h3>";
	echo"<h3 class='confirm_content'>moduleid: ".$_SESSION["moduleid"]."</h3>";
	echo"<h3 class='confirm_content'>modulename: ".$modulename."</h3>";
	echo"<h3 class='confirm_content'>assessmentid: ".$_SESSION["assessmentid"]."</h3>";
	echo"<h3 class='confirm_content'>assessmentname: ".$assessmentname."</h3>";
	echo"<h3 class='confirm_content'>studyhours: ".$_SESSION["studyhours"]."</h3>";
	echo"<h3 class='confirm_content'>date: ".$_SESSION["date"]."</h3>";
	echo"<h3 class='confirm_content'>time: ".$_SESSION["time"]."</h3>";	
	echo"<h3 class='confirm_content'>comment </h3>";
	if($_SESSION["comment"]!="") 
		{
		echo "<ul><li class='confirm_comment'>" . $_SESSION["comment"] . "</li>";
		if($_SESSION["comment2"]!="")
		{
		echo "<li class='confirm_comment'>".$_SESSION["comment2"]."</li>";
		if($_SESSION["comment3"]!="")
		{
		echo "<li class='confirm_comment'>".$_SESSION["comment3"]."</li></ul>";
		}
		else{echo "</ul>";}
		}
		else
		{
				echo "</ul>";
		}
		}
		elseif ($_SESSION["comment2"]!="")
		{
		echo "<ul><li class='confirm_comment'>" . $_SESSION["comment2"] . "</li>";
		if($_SESSION["comment3"]!="")
		{
			echo "<li class='confirm_comment'>".$_SESSION["comment3"]."</li></ul>";
		}
		}
		elseif ($_SESSION["comment3"]!="")
		{
			echo "<ul><li class='confirm_comment'>" . $_SESSION["comment3"] . "</li></ul>";
		}
		else
			{echo "<p class='confirm_comment'>No comment</p>";}

	mysqli_close($conn);
	?>
	<h2 id="confirm_message">Are you sure add the record to resit table?</h2>
	<div class="float">
	<form action="./tutor_confirmresit_script.php" method="post">
	<input type="submit" name="submitresitinsert" value="submit"/>
	</form></div>
	<div class="float">
	<a id="back" href = "../tutor_home/tutor_resitform_page.php">Back</a>
	</div><br><br><br><br><br><br><br><br><br>
<?php include '../php_includes/footer.php'?>
</body>
</html>
<?php
if (isset($_POST['submitresitinsert'])){
	include '../php_script/connectDB.php';
$resitid  = date("Y-m-d h:i:sa");
$studentid = $_SESSION['studentid'];
$cohort = $_SESSION['cohort'];
	$assessmentid = $_SESSION['assessmentid'];
$studyhours = $_SESSION['studyhours'];
$date = $_SESSION['date'];
$time = $_SESSION['time'];
$comment = $_SESSION['comment'];
$comment2 = $_SESSION['comment2'];
$comment3 = $_SESSION['comment3'];
if($comment=="" && $comment2=="" && $comment3=="")
{
	$comment="No Comment";
}

$sql = "INSERT INTO resit(resitid,studentid,cohort,assessmentid,studyhours,date,time,comment,comment2,comment3)
VALUES ('$resitid','$studentid','$cohort','$assessmentid','$studyhours','$date','$time','$comment','$comment2','$comment3')";
if ($runquery = $conn->query($sql))
	{
		$_SESSION['error']= "Resit added sucessfully";
	header('location:../tutor_home/tutor_resitform_page.php');
	exit();
	}

	$_SESSION['error']= "Doesnt work";
header('location:../tutor_home/tutor_resitform_page.php');
exit();

}
?>
