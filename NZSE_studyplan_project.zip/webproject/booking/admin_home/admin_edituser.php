<?php session_start(); ?>
<?php 
	if(!isset($_SESSION['usertype'])|| $_SESSION['usertype']!= 1){
		header('location:../error_page.php');
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
	<?php $title="Edit user"; ?>
	<?php include '../php_includes/head_elements.php'; ?>
	<?php include '../php_includes/alertbox.php'; ?>
</head>
<body>

<?php include '../php_includes/header_elements.php'; ?>
<div id='error'>
		<?php
				if(isset($_SESSION['error']))
				{	
					print $_SESSION['error'];	
					unset($_SESSION['error']);
				}
				
		?>
</div><!--error--><br />
<div class="tables">
<?php
	include '../php_script/connectDB.php';
	$result = "SELECT * FROM users ";
		echo "<table id='student_resit' class='border'>
		<tr>
		<th>Edit</th>
		<th>userid</th>
		<th>usertype</th>	
		<th>email</th>
		<th>useraccesslevel</th>
		</tr>";
		if ($runquery = $conn->query($result))
		{
			while($row = $runquery->fetch_assoc())
			{
				$userid = $row['userid'];
				$did = json_encode($row['userid']);
				if($row['usertype']==1)
				{
					$usertype="Admin";
				}
				elseif($row['usertype']==0)
				{
					$usertype="User";
				}
				else
				{
					$usertype="undefined";
				}
				echo "<tr>";
				echo "<td><a href='./admin_adduser.php'><img src='../pic/add.png' />Add</a> <a href='./admin_adduser.php?edit=$userid'><img src='../pic/edit.png' />Edit</a> <a href='./admin_adduser.php?copy=$userid'><img src='../pic/copy.png' />Copy</a> <a onclick='confirmAction($did)'><img src='../pic/delete.png' />Delete</a> <a onclick='resetAction($did)'><img src='../pic/reset.png' />Reset password</a></td>";
				
				echo "<td>" . $userid . "</td>";
				echo "<td>" . $usertype ."</td>";
				echo "<td>" . $row['email'] ."</td>";
				echo "<td>" . $row['useraccesslevel'] ."</td>";
				echo "</tr>";
			}
		}
		echo "</table>";
		echo"<br>";
		mysqli_close($conn);
		?>
</div>
		<script>
function confirmAction (id) {
    var did=id;
	alertify.confirm('Are you sure you wish to remove '+did+'?', function(e) {
        if (e) {
			
            window.location.href = "./admin_edituser.php?deletingid=" + did; 
            }
   
    });
}
function resetAction (id) {
    var did=id;
	alertify.confirm('Are you sure you wish to reset password for '+did+'?', function(e) {
        if (e) {
			
            window.location.href = "./admin_edituser.php?resetingid=" + did; 
            }
   
    });
}
</script>
<?php
include '../php_script/connectDB.php';
	if(isset($_GET['deletingid']))
	{
	$deletingid=$_GET['deletingid'];
	
	$result = "DELETE FROM users WHERE userid='".$deletingid."'";
	if($runquery=mysqli_query($conn,$result))
			{
			$_SESSION['error'] = "deleted successfully";
			header('location: ./admin_edituser.php');
			exit();
			}
			else
			{
				$_SESSION['error'] = "query wrong";
			header('location: ./admin_edituser.php');
			exit();
			}
	}
	if(isset($_GET['resetingid']))
	{
		$reset=$_GET['resetingid'];
		$password=md5("P@ssw0rd");
		$result = "UPDATE users SET password='$password' WHERE userid='$reset'";
		
		if ($runquery = $conn->query($result))
	{
	$_SESSION['error'] = "The password reset.";
	header('location: ./admin_edituser.php');
	exit();
	}
	else{
		$_SESSION['error'] = "doesn't work reseting.";
		header('location:./admin_edituser.php');
		exit();
	}
		}
		mysqli_close($conn);
?>
<br><br><br><br><br>
<?php include '../php_includes/footer.php';?>
</body>
</html>