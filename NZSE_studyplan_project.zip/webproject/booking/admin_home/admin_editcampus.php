<?php session_start(); ?>
<?php 
	if(!isset($_SESSION['usertype'])|| $_SESSION['usertype']!= 1){
		header('location:../error_page.php');
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
	<?php $title="Edit campus"; ?>
	<?php include '../php_includes/head_elements.php'; ?>
	<?php include '../php_includes/alertbox.php'; ?>
</head>
<body>

<?php include '../php_includes/header_elements.php'; ?>
<div id='error'>
		<?php
				if(isset($_SESSION['error']))
				{	
					print $_SESSION['error'];	
					unset($_SESSION['error']);
				}
				
		?>
</div><!--error--><br />
<div class="tables">
<?php
	include '../php_script/connectDB.php';
	$result = "SELECT c.* FROM campus c";
		echo "<table id='student_resit' class='border'>
		<tr>
		<th>Edit</th>
		<th>campusid</th>
		<th>campusname</th>
		<th>address</th>
		</tr>";
		$runquery = $conn->query($result);
		if (!$runquery)
		{
			die('Invalid query: ' . mysqli_error($conn));
		}
		else
		{
			while($row = $runquery->fetch_assoc())
			{
				$campusid = $row['campusid'];
				$did = json_encode($row['campusid']);
				echo "<tr>";
				echo "<td><a href='./admin_addcampus.php'><img src='../pic/add.png' />Add</a> <a href='./admin_addcampus.php?edit=$campusid'><img src='../pic/edit.png' />Edit</a> <a href='./admin_addcampus.php?copy=$campusid'><img src='../pic/copy.png' />Copy</a> <a onclick='confirmAction($did)'><img src='../pic/delete.png' />Delete</a></td>";
			
				echo "<td>" . $campusid . "</td>";
				echo "<td>" . $row['campusname'] ."</td>";
				echo "<td>" . $row['address'] ."</td>";
				
				echo "</tr>";
			}
		}
		
		echo "</table>";
		echo"<br>";
		mysqli_close($conn);
?>
</div>
<script>
function confirmAction (id) {
    var did=id;
	alertify.confirm('Are you sure you wish to remove '+did+'?', function(e) {
        if (e) {
			
            window.location.href = "./admin_editcampus.php?deletingid=" + did; 
            }
   
    });
}
</script>
<?php
include '../php_script/connectDB.php';
	if(isset($_GET['deletingid']))
	{
	$deletingid=$_GET['deletingid'];
	unset($_GET['deletingid']);
	$result = "DELETE FROM campus WHERE campusid='".$deletingid."'";
	if($runquery=mysqli_query($conn,$result))
			{
			$_SESSION['error'] = "deleted successfully";
			header('location: ./admin_editcampus.php');
			exit();
			}
			else
			{
				$_SESSION['error'] = "query wrong";
			header('location: ./admin_editcampus.php');
			exit();
			}
	}
		mysqli_close($conn);
?>
<br><br><br><br><br>
<?php include '../php_includes/footer.php';?>
</body>
</html>