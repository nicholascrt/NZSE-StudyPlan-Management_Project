<?php
	session_start();
	include '../php_script/connectDB.php';
	
	if(isset($_SESSION['updatingid']))
	{
		$updatingid=$_SESSION['updatingid'];
	}
	$campusname=$_GET['campusname'];
	$campusid=$_GET['campusid'];
	$address=$_GET['address'];
	
	//checking campus id
 $query = "SELECT COUNT(*) as cnt FROM campus WHERE campusid= '".$campusid."'";
$runquery = mysqli_query($conn, ($query));
$row = mysqli_fetch_array($runquery); 
$cnt = $row['cnt'];

if($cnt >= 1)
{
	$_SESSION['errorid'] = $campusid;
	$_SESSION['error'] = "The campus id already exists.";
	header('location: ./admin_addcampus.php');
	exit();
 }
	//adding new
	if(isset($_GET['new']))
	{
	
	$result = "INSERT INTO campus(campusname,campusid,address)
				VALUES ('$campusname','$campusid','$address')";
		
		if ($runquery = $conn->query($result))
	{
	$_SESSION['error'] = "The campus added.";
	header('location: ./admin_addcampus.php');
	exit();
	}
	else{
		$_SESSION['errorid'] = $campusid;
		$_SESSION['error'] = "doesn't work.";
		header('location:./admin_addcampus.php');
		exit();
	}
	}
	//editing
	if(isset($_GET['submit']))
	{
	$result = "UPDATE campus SET campusname='$campusname',address='$address' WHERE campusid='$updatingid'";
		
		if ($runquery = $conn->query($result))
	{
		
	$_SESSION['error'] = "The campus edited.";
	header('location: ./admin_addcampus.php');
	exit();
	}
	else{
		$_SESSION['errorid'] = $updatingid;
		$_SESSION['error'] = "doesn't work.";
		header('location:./admin_addcampus.php');
		exit();
	}
	}
  mysqli_close($conn);
?>
