<?php
	session_start();
	include '../php_script/connectDB.php';
	
	if(isset($_SESSION['updatingid']))
	{
		$updatingid=$_SESSION['updatingid'];
	}
	$roomid=$_GET['roomid'];
	$roomname=$_GET['roomname'];
	$roomtype=$_GET['roomtype'];
	$capacity=$_GET['capacity'];
	$buildingid=$_GET['buildingid'];
	$roomaccesslevel=$_GET['roomaccesslevel'];
	$floornumber=$_GET['floornumber'];
	
	 //checking room id
 $query = "SELECT COUNT(*) as cnt FROM room WHERE roomid= '".$roomid."'";
$runquery = mysqli_query($conn, ($query));
$row = mysqli_fetch_array($runquery); 
$cnt = $row['cnt'];

if($cnt >= 1)
{
	$_SESSION['errorid'] = $roomid;
	$_SESSION['error'] = "The room id already exists.";
	header('location: ./admin_addroom.php');
	exit();
 }
 
//checking building id
	$query = "SELECT COUNT(*) as cnt FROM building WHERE building.buildingid= '".$buildingid."'";
$runquery = mysqli_query($conn, ($query));
if($runquery){
$row = mysqli_fetch_array($runquery); 
$cnt = $row['cnt'];
}
else
{
	$_SESSION['errorid'] = $roomid;
	$_SESSION['error'] = "query.";
		header('location:./admin_addbuilding.php');
		exit();
}
if($cnt < 1)
{
	$_SESSION['errorid'] = $roomid;
	$_SESSION['error'] = "There is no such building id.";
	$_SESSION['lead'] = "<br><a href='./admin_editbuilding.php'>click here to register the building id</a>";
	header('location: ./admin_addroom.php'); 
	exit();
 } 	
	//adding new
	if(isset($_GET['new']))
	{
	
	$result = "INSERT INTO rooms(roomid,roomname,roomtype,buildingid,roomaccesslevel,floornumber,capacity)
				VALUES ('$roomid','$roomname','$roomtype','$buildingid','$roomaccesslevel','$floornumber','$capacity')";
		
		if ($runquery = $conn->query($result))
	{
	$_SESSION['error'] = "The room added.";
	header('location: ./admin_addroom.php');
	exit();
	}
	else{
		$_SESSION['errorid'] = $roomid;
		$_SESSION['error'] = "doesn't work.";
		header('location:./admin_addroom.php');
		exit();
	}
	}
	//editing
	if(isset($_GET['submit']))
	{
		
	$result = "UPDATE rooms SET roomname='$roomname',roomtype='$roomtype',capacity='$capacity',roomaccesslevel='$roomaccesslevel',floornumber='$floornumber',buildingid='$buildingid' WHERE roomid='$updatingid'";
		
		if ($runquery = $conn->query($result))
	{
	$_SESSION['error'] = "The room edited.";
	header('location: ./admin_addroom.php');
	exit();
	}
	else{
		$_SESSION['errorid'] = $updatingid;
		$_SESSION['error'] = "doesn't work.";
		header('location:./admin_addroom.php');
		exit();
	}
	}
  mysqli_close($conn);
?>
