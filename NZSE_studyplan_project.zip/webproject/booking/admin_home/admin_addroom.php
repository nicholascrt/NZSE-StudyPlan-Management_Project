<?php session_start();?>
<?php 
	if(!isset($_SESSION['usertype'])|| $_SESSION['usertype']!= 1){
		header('location:../error_page.php');
	}
	
?>
<!--bring values into form-->
<?php
	if(isset($_GET['copy']) || isset($_GET['edit']) || isset($_SESSION['errorid']))
	{
		if(isset($_GET['copy']))
		{
		$roomid=$_GET['copy'];
		}
		elseif(isset($_GET['edit']))
		{
		$roomid=$_GET['edit'];
		}
		else
		{
			$roomid=$_SESSION['errorid'];
			unset($_SESSION['errorid']);
		}
	include '../php_script/connectDB.php';
	$result = "SELECT r.* FROM rooms r WHERE r.roomid='".$roomid."'";
		if($runquery=mysqli_query($conn,$result))
		{
			while($row = $runquery->fetch_assoc())
			{
				$_SESSION['roomid']=$row['roomid'];
				$_SESSION['roomname']=$row['roomname'];
				$_SESSION['roomtype']=$row['roomtype'];
				$_SESSION['buildingid']=$row['buildingid'];
				$_SESSION['floornumber']=$row['floornumber'];
				$_SESSION['capacity']=$row['capacity'];
				$_SESSION['roomaccesslevel']=$row['roomaccesslevel'];
			}
		}
		else
		{
			$_SESSION['error']="couldnt bring copied data";
		}
		mysqli_close($conn);
	}
		
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
	<?php $title="Add Room"; ?>
	<?php include '../php_includes/head_elements.php'; ?>
	<?php include '../php_includes/alertbox.php'; ?>
</head>
<body>
<?php include '../php_includes/header_elements.php'; ?>
<div id='error'>
		<?php
				if(isset($_SESSION['error']))
				{	
					print $_SESSION['error'];
					if(isset($_SESSION['lead']))
					{
						print $_SESSION['lead'];
					}
					unset($_SESSION['error']);
					unset($_SESSION['lead']);
				}
				
		?>
</div><!--error--><br />
<div id="container">
<form id="form1" action="./admin_addroom_script.php">
<fieldset><p class="first">
<label for='roomid'>Room id:</label>
<?php if(!isset($_GET['edit'])) {echo "<input type='text' name='roomid' value='";}
if(isset($_SESSION['roomid'])) {echo $_SESSION['roomid'];}
if(!isset($_GET['edit'])) {echo "'>";}
?>
<br></p>
<p>
<label for="roomname">Room name:</label>
<input type="text" name="roomname" value="<?php if(isset($_SESSION['roomname'])) echo $_SESSION['roomname'];?>">
<br></p>
<p>
<label for="roomtype">Room type:</label>
<input type="text" name="roomtype" value="<?php if(isset($_SESSION['roomtype'])) echo $_SESSION['roomtype'];?>">
<br></p>
<p>
<?php
include '../php_script/connectDB.php';

$sql="SELECT * FROM building";
$result = mysqli_query($conn,$sql);

echo "<label for='module'>Building: </label>
<select name='buildingid'>";
echo "<option>Select a building id</option>";
while($row = mysqli_fetch_array($result)) {
	$buildingid = $row['buildingid'];
	echo "<option value=".$buildingid; if(isset($_SESSION['buildingid'])) {if($_SESSION['buildingid']==$buildingid) {echo " selected";}} echo ">" .$row['buildingname']."</option>";
}
echo "</select>";
mysqli_close($conn);
?>
<br></p>
<p>
<label for="floornumber">Floor number:</label>
<input type="text" name="floornumber" value="<?php if(isset($_SESSION['floornumber'])) echo $_SESSION['floornumber'];?>">
<br></p>
<p>
<label for="capacity">Capacity:</label>
<input type="text" name="capacity" value="<?php if(isset($_SESSION['capacity'])) echo $_SESSION['capacity'];?>">
<br></p>
<p>
<label for="roomaccesslevel">Room access level:</label>
<input type="text" name="roomaccesslevel" value="<?php if(isset($_SESSION['roomaccesslevel'])) echo $_SESSION['roomaccesslevel'];?>">
<br></p>
</fieldset>
		<p class="submit">
<?php if(isset($_GET['edit'])) {echo "<input type='submit' name='submit' value='submit'>"; $_SESSION['updatingid']=$_SESSION['roomid'];} else {echo "<input type='submit' name='new' value='submit'>";}?>
</p></form>
</div>
<script>
	$("#form1").on('submit', function () 
		{	
			var flag;
			var d = 5000;
			var roomid = document.forms["form1"]["roomid"].value;
			if (roomid == null || roomid == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("room id is required");
				flag=false;
			}
			var roomname = document.forms["form1"]["roomname"].value;
			if (roomname == null || roomname == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("room name is required");
				flag=false;
			}
			var roomtype = document.forms["form1"]["roomtype"].value;
			if (roomtype == null || roomtype == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("room type is required");
				flag=false;
			}
			var buildingid = document.forms["form1"]["buildingid"].value;
			if (buildingid == null || buildingid == "Select a building id") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("building id is required");
				flag=false;
			}
			var floornumber = document.forms["form1"]["floornumber"].value;
			if (floornumber == null || floornumber == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("floornumber is required");
				flag=false;
			}
			var capacity = document.forms["form1"]["capacity"].value;
			if (capacity == null || capacity == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("capacity is required");
				flag=false;
			}
			var roomaccesslevel = document.forms["form1"]["roomaccesslevel"].value;
			if (roomaccesslevel == null || roomaccesslevel == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("room access level is required");
				flag=false;
			}
			return flag;
		});
		</script>
		<br><br>
<a id="back" href="./admin_editroom.php">Go back to view rooms</a>
<?php
	unset($_SESSION['roomid'],$_SESSION['roomname'],$_SESSION['roomtype'],$_SESSION['buildingid'],$_SESSION['floornumber'],$_SESSION['capacity'],$_SESSION['roomaccesslevel']);
?>
<br><br><br><br><br><br>
<?php include '../php_includes/footer.php';?>
</body>
</html>