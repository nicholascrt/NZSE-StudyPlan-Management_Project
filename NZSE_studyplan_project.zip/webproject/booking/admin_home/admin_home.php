<?php session_start(); ?>
<?php 
	if(!isset($_SESSION['usertype'])|| $_SESSION['usertype']!= 1){
		header('location:../error_page.php');
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
	<?php $title="Admin Home"; ?>
	<?php include '../php_includes/head_elements.php'; ?>
</head>
<body>
<?php include '../php_includes/header_elements.php'; ?>
<section>
<div class = "button">
	<fieldset>
<a href="./admin_editroom.php"><h2>Edit Room</h2></a>
<a href="./admin_editbuilding.php"><h2>Edit Building</h2></a>
<a href="./admin_editcampus.php"><h2>Edit Campus</h2></a>
<a href="./admin_edituser.php"><h2>Edit User</h2></a>
</fieldset>
	</div>
	
</section>
<?php include '../php_includes/footer.php';?>
</body>
</html>