 $("#login-button").click(function(event){
		 //event.preventDefault();
	 
	 $('form').fadeOut(300);
	 $('.wrapper').addClass('form-success');
});