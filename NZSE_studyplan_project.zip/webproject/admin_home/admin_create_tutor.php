<?php session_start(); ?>
<?php 
	if(!isset($_SESSION['usertype'])|| $_SESSION['usertype']!=3){
		header('location:../error_page.php');
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">

<head>
		<?php $title="create tutor"; ?>
	<?php include '../php_includes/head_elements.php' ?>
<script src="../js/jquery-1.9.1.js"></script>
<script src="../js/alertify.min.js"></script>
<link rel="stylesheet" href="../css/css_alertboxes/alertify.core.css" />
<link rel="stylesheet" href="../css/css_alertboxes/alertify.default.css" />
</head>
<body>

<?php
if (isset($_POST['submitregi'])){
include '../php_script/connectDB.php';

$tutorid = $_POST['tutor_id'];
$tutorname = $_POST['tutor_name'];
$email = $_POST['email_tutor'];
$password = md5("P@ssw0rd");

if(empty($tutorid)||empty($tutorname))
{	
	$_SESSION["error"] = "Please fill in all fields.";
	header('location: ./admin_create_tutor.php'); 
	exit();
}
if (!preg_match('/^i[0-9]{6}$/', $tutorid)) 
	{
		$_SESSION['error']="Invailded tutor id format, please try again.";
		header('location: ./admin_create_tutor.php'); 
		exit();
	}
	
if (!preg_match('/^[a-z]*.[a-z]*$/', $tutorname)) 
	{
		$_SESSION['error']="Invailded name format, please try again.";
		header('location: ./admin_create_tutor.php'); 
		exit();
	}
	
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
{
	$_SESSION['error']="Invailded email, please try again.";
	header('location: ./admin_create_tutor.php'); 
	exit();
}
$sql = "INSERT INTO userid(id,username,password,email,usertype)
VALUES ('$tutorid', '$tutorname', '$password','$email','3')";

if ($conn->query($sql) === TRUE)
{
	$_SESSION['error']="Tutor created successfully.";
} 
else 
{
	$_SESSION['error']="Tutor ID is already existed, please try again.";
}
    header('location: ./admin_create_tutor.php');
	exit();
}
?>
	<?php include '../php_includes/header_elements.php' ?>

	<div id='chgpw_form'>
	<div id='error'>
		<?php
				if(isset($_SESSION['error']))
				{	
					print $_SESSION['error'];
					unset($_SESSION['error']);
				}
		?>
	</div><!--error-->
		<div id="container">


		
		<h2>Register form</h2>
					
		<form id="form1" action="./admin_create_tutor.php" method="post">	
		
	
			<fieldset><legend>Contact form</legend>
				<p class="first">
					<label>Tutor ID:</label>
		<input type='text' name='tutor_id'><br />
				</p>
				<p>
					<label>Tutor Name:</label>
		<input type='text' name='tutor_name'><br />
				</p>
				<p>
					<label>Email:</label>
		<input type='text' name='email_tutor'><br />	
				</p>
			</fieldset>					

			<p class="submit"><button type="submit" name='submitregi'>Register</button></p>		
						
		</form>	
		</div>
	</div><!--chgpw_form-->
	<script>
	$("#form1").on('submit', function () 
		{	
			var flag;
			var d = 5000;
			var tutor_id = document.forms["form1"]["tutor_id"].value;
			if (tutor_id == null || tutor_id == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("tutor id is required");
				flag=false;
			}
			var tutor_name = document.forms["form1"]["tutor_name"].value;
			if (tutor_name == null || tutor_name == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("tutor name is required");
				flag=false;
			}
			var email_tutor = document.forms["form1"]["email_tutor"].value;
			if (email_tutor == null || email_tutor == "") 
			{
				d += 500;
				alertify.set({ delay: d });
				alertify.log("email tutor is required");
				flag=false;
			}
			return flag;
		});
		</script>
	<?php include '../php_includes/footer.php'?>
	
</body>
</html>