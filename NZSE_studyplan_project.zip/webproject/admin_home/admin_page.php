<?php session_start(); ?>
<?php 
	if(!isset($_SESSION['usertype'])|| $_SESSION['usertype']!=3){
		header('location:../error_page.php');
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
		<?php $title="admin home"; ?>
	<?php include '../php_includes/head_elements.php'; ?>
</head>
<body>
	<?php include '../php_includes/header_elements.php'; ?>
	
	<div class = "button">
	<fieldset>
	<form  action="../admin_home/admin_create_tutor.php" method="get">
	<input type="submit" value="Create Tutor Account" > </input>
	</form>
	<form  action="../admin_home/admin_changeprofile_page.php" method="get">
	<input type="submit" value="Change Profile"></input>
	</form>
		<form action="../admin_home/admin_changepw_page.php" method="get">
		<input type="submit" value="Change Password"></input>
		</form>
	</fieldset>
	</div>
	
	<?php include '../php_includes/footer.php'?>
</body>
</html>
				