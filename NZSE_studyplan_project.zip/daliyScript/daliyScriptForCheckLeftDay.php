<?php session_start(); ?>

<?php 
include '../webproject/php_script/connectDB.php';

//Get current date
$currentDate = new DateTime(date("Y/m/d"));

//Sql query for resit table
$selectResit = "SELECT r.*, a.title, u.username
FROM resit r, assessment a, userid u
WHERE r.completed=0
AND r.assessmentid = a.assessmentid
AND r.studentid = u.id
";
$runselectResit = mysqli_query($conn, $selectResit);

//Retrive data from query
while($rowResit = mysqli_fetch_assoc($runselectResit)) 
{
		$resitDate = new DateTime($rowResit['date']);
		$resitDateInterval = $currentDate->diff($resitDate);
		$diffresit=$resitDateInterval->format('%a');
		
		
		$_SESSION['studentname']=$rowResit['username'];
		$_SESSION['studentid']=$rowResit['studentid'];
		$_SESSION['cohort']=$rowResit['cohort'];
		$_SESSION['assessmentID']=$rowResit['assessmentid'];
		$_SESSION['date']=$rowResit['date'];
		$_SESSION['time']=$rowResit['time'];
		$_SESSION['assessmentname']=$rowResit['title'];
		
		$selectStudentEmail = "SELECT email FROM userid WHERE id='".$rowResit['studentid']."'";
		$runselectStudentEmail = mysqli_query($conn, $selectStudentEmail);
		$rowEmail = mysqli_fetch_row($runselectStudentEmail);
		
		if($diffresit==7){
			$_SESSION['studentemail']=$rowEmail[0];
			$_SESSION['emailType']='resitB7';
			include './sendEmail.php';
		}elseif ($diffresit==1){
			$_SESSION['studentemail']=$rowEmail[0];
			$_SESSION['emailType']='resitB1';
			include './sendEmail.php';
		}
}
 
 
 //Sql query for reenroll table
$selectReenroll = "SELECT r.*, c.modulename, u.username
FROM reenrollment r, courses c, userid u
WHERE r.moduleid=c.moduleid
AND r.studentid = u.id
";
$runselectReenroll = mysqli_query($conn, $selectReenroll);

//Retrive data from query
while($rowReenroll = mysqli_fetch_assoc($runselectReenroll)) 
{
	$reenrollDate = new DateTime($rowReenroll['startdate']);
	$resitDateInterval = $currentDate->diff($reenrollDate);
	$diff=$resitDateInterval->format('%a');
	
	
	$_SESSION['studentname']=$rowReenroll['username'];
	$_SESSION['studentid']=$rowReenroll['studentid'];
	$_SESSION['cohort']=$rowReenroll['cohort'];
	$_SESSION['moduleID']=$rowReenroll['moduleid'];
	$_SESSION['startdate']=$rowReenroll['startdate'];
	$_SESSION['enddate']=$rowReenroll['enddate'];
	$_SESSION['classtime']=$rowReenroll['classtime'];
	$_SESSION['labtime']=$rowReenroll['labtime'];
	$_SESSION['modulename']=$rowReenroll['modulename'];
	
	$_SESSION['PLemail']='rashi@nzse.ac.nz';
	
	if($diff==7){
		$_SESSION['emailType']='reenrollB7';
		include './sendEmail.php';
	}elseif ($diff==1){
		$_SESSION['emailType']='reenrollB1';
		include './sendEmail.php';
	}
}
mysqli_close($conn);
?>