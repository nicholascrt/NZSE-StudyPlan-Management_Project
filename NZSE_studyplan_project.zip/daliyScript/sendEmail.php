	<?php 
	if(isset($_SESSION['emailType']))
	{
		$emailType=$_SESSION['emailType'];
		$txt = "
		<html>
		<style>
		table {margin-left:auto;margin-right:auto;}
		table th{background-color: #B0B0B0;}
		table.front td {text-align: left; width:180px;height:38px; padding-left:10px;}
		table.front th {font-size:14px; width:100px;}
		table,th,td {border: 1px solid black;border-collapse: collapse;}
		p {width:860px;}
		fieldset { width:900px;}
		</style><body><center><a href='http://www.nzse.ac.nz/'>
		<img src='http://www.careersexpo.org.nz/uploads/feusers/12227_image.jpg' width='25%' height='20%'></a>
		<h1>Study Notification</h1></center>";
		
		if ($emailType=='resitB7'){
			//Email to student 7 days befor reseit
			$email=$_SESSION['studentemail'];
			$txt .= "
	<table class='front'>
		<tr>
			<th>Student ID</th>
			<td>".$_SESSION['studentid']."</td>
			<th>Cohort</th>
			<td>".$_SESSION['cohort']."</td>
		</tr>
		<tr>
			<th>Student Name</th>
			<td colspan='3'>".$_SESSION['studentname']."</td>
		</tr>
		<tr>
			<th>Assessment ID</th>
			<td>".$_SESSION['assessmentID']."</td>
			<th>Assessment name</th>
			<td>".$_SESSION['assessmentname']."</td>
		</tr>
		<tr>
			<th>Date</th>
			<td colspan='3'>".$_SESSION['date']." ".$_SESSION['time']."</td>
		</tr>
		<tr>
			<th>Comment</th>
			<td colspan='3'>Your resit is apporaching on next week.</td>
		</tr>
	</table><br /><center><fieldset>";
		 session_unset();
	//=================================================================================================================================================
	
			}elseif ($emailType=='resitB1'){
			//Email to student 1 day before resit
			$email=$_SESSION['studentemail'];
			$txt .= "
	<table class='front'>
		<tr>
			<th>Student ID</th>
			<td>".$_SESSION['studentid']."</td>
			<th>Cohort</th>
			<td>".$_SESSION['cohort']."</td>
		</tr>
		<tr>
			<th>Student Name</th>
			<td colspan='3'>".$_SESSION['studentname']."</td>
		</tr>
		<tr>
			<th>Assessment ID</th>
			<td>".$_SESSION['assessmentID']."</td>
			<th>Assessment name</th>
			<td>".$_SESSION['assessmentname']."</td>
		</tr>
		<tr>
			<th>Date</th>
			<td colspan='3'>".$_SESSION['date']." ".$_SESSION['time']."</td>
		</tr>
		<tr>
			<th>Comment</th>
			<td colspan='3'>Your have a resit tomorrow.</td>
		</tr>
	</table><br /><center><fieldset>";
	//=================================================================================================================================================
		session_unset();
				}elseif ($emailType=='reenrollB1'){
			//Email to PL 1 day before re-enroll
			$email=$_SESSION['PLemail'];
			$txt .= "
	<table class='front'>
		<tr>
			<th>Student ID</th>
			<td>".$_SESSION['studentid']."</td>
			<th>Cohort</th>
			<td>".$_SESSION['cohort']."</td>
		</tr>
		<tr>
			<th>Student Name</th>
			<td colspan='3'>".$_SESSION['studentname']."</td>
		</tr>
		<tr>
			<th>Module ID</th>
			<td>".$_SESSION['moduleID']."</td>
			<th>Module name</th>
			<td>".$_SESSION['modulename']."</td>
		</tr>
		<tr>
			<th>Start Date</th>
			<td>".$_SESSION['startdate']."</td>
			<th>End Date</th>
			<td>".$_SESSION['enddate']."</td>
		</tr>
		<tr>
			<th>Class time</th>
			<td>".$_SESSION['classtime']."</td>
			<th>Lab time</th>
			<td>".$_SESSION['labtime']."</td>
		</tr>
			<th>Comment</th>
			<td colspan='3'>This student will have a re-enrollment tomorrow.</td>
		</tr>
	</table><br /><center><fieldset>";
	//=================================================================================================================================================
		session_unset();
				}elseif ($emailType=='reenrollB7'){
			//Email to PL 7 days before re-enroll
			$email=$_SESSION['PLemail'];
			$txt .= "
	<table class='front'>
		<tr>
			<th>Student ID</th>
			<td>".$_SESSION['studentid']."</td>
			<th>Cohort</th>
			<td>".$_SESSION['cohort']."</td>
		</tr>
		<tr>
			<th>Student Name</th>
			<td colspan='3'>".$_SESSION['studentname']."</td>
		</tr>
		<tr>
			<th>Module ID</th>
			<td>".$_SESSION['moduleID']."</td>
			<th>Module name</th>
			<td>".$_SESSION['modulename']."</td>
		</tr>
		<tr>
			<th>Start Date</th>
			<td>".$_SESSION['startdate']."</td>
			<th>End Date</th>
			<td>".$_SESSION['enddate']."</td>
		</tr>
		<tr>
			<th>Class time</th>
			<td>".$_SESSION['classtime']."</td>
			<th>Lab time</th>
			<td>".$_SESSION['labtime']."</td>
		</tr>
		<tr>
			<th>Comment</th>
			<td colspan='3'>This student will have a re-enrollment on next week.</td>
		</tr>
	</table><br /><center><fieldset>";
	//=================================================================================================================================================
		session_unset();
	}
				
	$txt .="<p><b>Disclaimer</b>: This email may contain legally privileged confidential information and is intended only for the named recipient. 
	If you are not the intended recipient any use, disclosure or copying of the message or attachment(s) is strictly prohibited. 
	If you have received this message in error please notify the sender immediately and destroy it and any attachment(s). 
	Any views expressed in this e-mail may be those of the individual sender and may not necessarily reflect the views of New 
	Zealand School of Education Limited.</p>
	<b>Please consider the environment before printing.</b></fieldset></center></body></html>";

		$subject = "Notification from NZSE system";
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

		$headers .= 'From: <NZSEsystem@nzse.ac.nz>' . "\r\n";

		mail($email,$subject,$txt,$headers);
	}
	?>
	
